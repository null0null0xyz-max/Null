﻿# Nuan Tap - install step
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$data = Join-Path $here "data"
if (-not (Test-Path $data)) { New-Item -ItemType Directory -Path $data | Out-Null }
