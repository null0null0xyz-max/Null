﻿# Nuan Tap - setup step
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfg = Join-Path $here "data\config.txt"
if (-not (Test-Path $cfg)) { "port=8153" | Out-File -Encoding utf8 $cfg }
