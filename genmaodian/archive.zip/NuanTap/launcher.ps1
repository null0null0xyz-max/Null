﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "Nuan Tap"
Clear-Host
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

$logo = @(
    '███╗   ██╗██╗   ██╗ █████╗ ███╗   ██╗    ████████╗ █████╗ ██████╗'
    '████╗  ██║██║   ██║██╔══██╗████╗  ██║    ╚══██╔══╝██╔══██╗██╔══██╗'
    '██╔██╗ ██║██║   ██║███████║██╔██╗ ██║       ██║   ███████║██████╔╝'
    '██║╚██╗██║██║   ██║██╔══██║██║╚██╗██║       ██║   ██╔══██║██╔═══╝'
    '██║ ╚████║╚██████╔╝██║  ██║██║ ╚████║       ██║   ██║  ██║██║'
    '╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝       ╚═╝   ╚═╝  ╚═╝╚═╝'
)
$colors = @("Red","DarkYellow","Yellow","Green","Cyan","Magenta")
Write-Host ""
for ($i = 0; $i -lt $logo.Count; $i++) {
    Write-Host ("  " + $logo[$i]) -ForegroundColor $colors[$i % $colors.Count]
}
$w = ($logo | Measure-Object -Property Length -Maximum).Maximum + 2
$tag = "powered by 根锚点下载"
Write-Host ((" " * [Math]::Max(0, $w - $tag.Length - 6)) + $tag) -ForegroundColor DarkGray
Write-Host ""

function Step($text) {
    $sec = Get-Random -Minimum 1 -Maximum 6
    $frames = @("|","/","-","\")
    $end = (Get-Date).AddSeconds($sec); $f = 0
    while ((Get-Date) -lt $end) {
        Write-Host ("`r  [" + $frames[$f % 4] + "] " + $text + "   ") -NoNewline -ForegroundColor Yellow
        Start-Sleep -Milliseconds 120; $f++
    }
    Write-Host ("`r  [OK] " + $text + " (" + $sec + "s)   ") -ForegroundColor Green
}

Step "Loading application..."
Step "Running install.ps1..."
& (Join-Path $here "install.ps1")
Step "Running setup.ps1..."
& (Join-Path $here "setup.ps1")
Step "Starting isolated environment..."

$port = 8153
$url = "http://localhost:$port/"
$root = Join-Path $here "app"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)
try { $listener.Start() } catch { Write-Host "  Port $port is busy." -ForegroundColor Red; exit 1 }
Write-Host ""
Write-Host "  Nuan Tap is running: $url" -ForegroundColor Cyan
Write-Host "  Close this window to stop." -ForegroundColor DarkGray
Start-Process $url

$types = @{ ".html"="text/html; charset=utf-8"; ".js"="application/javascript"; ".css"="text/css"; ".png"="image/png"; ".ico"="image/x-icon" }
while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    $path = $ctx.Request.Url.AbsolutePath.TrimStart("/")
    if ($path -eq "") { $path = "index.html" }
    $file = Join-Path $root $path
    if ((Test-Path $file -PathType Leaf) -and ([IO.Path]::GetFullPath($file).StartsWith([IO.Path]::GetFullPath($root)))) {
        $bytes = [IO.File]::ReadAllBytes($file)
        $ext = [IO.Path]::GetExtension($file).ToLower()
        if ($types.ContainsKey($ext)) { $ctx.Response.ContentType = $types[$ext] }
        $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    } else { $ctx.Response.StatusCode = 404 }
    $ctx.Response.Close()
}
