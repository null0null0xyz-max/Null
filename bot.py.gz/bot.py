"""Telegram-бот для Claude Code на Wispbyte.

- стриминг ответа в черновик (sendRichMessageDraft) + блок <tg-thinking> со статусами шагов
- нативная кнопка Stop (can_stop) и событие stopped_message_generation
- выбор модели, провайдеры (добавить/убрать/переключить), сессии с продолжением
- файлы проекта живут в Telegram-канале (tgfs.py), команды выполняются на Render (rexec)

Env: BOT_TOKEN, REXEC_URL, REXEC_TOKEN (OWNER_ID, CHANNEL_ID — необязательно, определяются сами)
     необязательно: CLAUDE_BIN (по умолчанию "claude"), ANTHROPIC_API_KEY
"""
from dotenv_min import load_env; load_env()
import os, re, io, json, glob, time, html, queue, base64, shutil, random, secrets, tarfile, mimetypes, threading, subprocess, itertools, requests
import importlib.machinery, importlib.util, hmac, hashlib
from tgfs import TgFS
import fast


def _load_tgctl():
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tgctl")
    loader = importlib.machinery.SourceFileLoader("tgctl", p)
    mod = importlib.util.module_from_spec(importlib.util.spec_from_loader("tgctl", loader))
    loader.exec_module(mod)
    return mod


tgctl = _load_tgctl()

TOKEN = os.environ["BOT_TOKEN"]
CLAUDE = os.environ.get("CLAUDE_BIN", "claude")
HERE = os.path.dirname(os.path.abspath(__file__))
WS = os.path.join(HERE, "workspace")
CFG_PATH = os.path.join(HERE, "config.json")
API = f"https://api.telegram.org/bot{TOKEN}/"

DEFAULT_CFG = {
    "providers": {"anthropic": {"base_url": "", "token": "", "models": ["sonnet", "opus", "haiku"]}},
    "provider": "anthropic", "model": "sonnet", "chats": {},
    "effort": "", "mode": "bypass", "ecc_skills": True,
}
EFFORTS = ["low", "medium", "high", "xhigh", "max", "ultrathink"]
MODES = {"bypass": "🚀 Всё разрешено", "plan": "📋 План (только чтение)", "acceptEdits": "✏️ Правки без Bash"}
CLAUDE_DIR = os.path.expanduser("~/.claude")
ECC_URL = "https://codeload.github.com/affaan-m/ECC/tar.gz/refs/heads/main"
ECC_PARTS = ("commands/", "agents/", "skills/", "rules/common/")
# команды Claude Code, которые бот передаёт в Claude как есть (работают в -p)
PASS = {"compact": "/compact", "context": "/context", "init": "/init",
        "review": "/review", "security_review": "/security-review"}
BUILTIN = [("menu", "Модель, провайдеры, effort, режим"), ("new", "Новая сессия"),
           ("clear", "Очистить чат и удалить сессию"), ("resume", "Прошлые сессии"),
           ("effort", "Effort: low/medium/high/xhigh/max"), ("model", "Сменить модель"),
           ("mode", "Режим разрешений (план / всё)"), ("plan", "Включить/выключить режим плана"),
           ("compact", "Сжать контекст сессии"), ("context", "Сколько занято контекста"),
           ("init", "Создать CLAUDE.md для проекта"),
           ("review", "Ревью кода"), ("security_review", "Проверка безопасности"),
           ("stop", "Остановить задачу"), ("live", "Трансляция: задачи и агенты в реальном времени"), ("fast", "Быстрые ответы: вкл/выкл"), ("where", "Где работает Claude: GitHub или здесь"), ("status", "Состояние бота и сервера"),
           ("files", "Файлы проекта"), ("usage", "Кредиты, токены, остаток"), ("balance", "Балансы всех провайдеров"),
           ("agents", "Чаты агентов последней задачи"), ("skills", "Навыки"),
           ("repair", "Восстановить оглавление и index в канале"),
           ("chats", "Группы и каналы, где я отвечаю"), ("prompt", "Инструкции для этого чата"),
           ("ecc", "Команды Everything Claude Code"),
           ("help", "Справка")]
TOOL_ICONS = {"Bash": "⚙️", "Read": "📖", "Write": "✏️", "Edit": "✏️", "MultiEdit": "✏️",
              "Grep": "🔎", "Glob": "🔎", "WebFetch": "🌐", "WebSearch": "🌐", "Task": "🧩", "Agent": "🧩", "Skill": "🧠", "TodoWrite": "📝"}

cfg = json.load(open(CFG_PATH)) if os.path.exists(CFG_PATH) else {}
for _k, _v in json.loads(json.dumps(DEFAULT_CFG)).items():
    cfg.setdefault(_k, _v)
# OWNER_ID / CHANNEL_ID можно не задавать: владелец = первый, кто написал /start,
# канал = первый канал, куда бота добавили админом. Оба запоминаются в config.json.
# Модели reformboss: добавляются к провайдеру с этим base_url (свои модели пользователя не трогаем)
REFORMBOSS_MODELS = ["glm-5.3", "glm-5.3-flash", "glm-5.3-prime", "deepseek-v4.1-flash", "deepseek-v4-pro",
                     "kimi-k3", "kimi-k2.7-code", "kimi-k2.6", "qwen3.8-max", "qwen3.8-max-0902",
                     "grok-chat-fast", "grok-4.7", "grok-composer-2.5-fast"]
for _p in cfg.get("providers", {}).values():
    if "reformboss" in (_p.get("base_url") or ""):
        _p["models"] = list(dict.fromkeys((_p.get("models") or []) + REFORMBOSS_MODELS))


def allowed_models(p):
    """new-api/one-api: у ключа бывает белый список моделей (model_limits). None — ограничений нет/не узнать."""
    if not p.get("base_url") or not p.get("token"):
        return None
    try:
        d = requests.get(p["base_url"] + "/api/usage/token/", timeout=15,
                         headers={"Authorization": "Bearer " + p["token"]}).json().get("data") or {}
        if d.get("model_limits_enabled") and isinstance(d.get("model_limits"), dict):
            return {m for m, on in d["model_limits"].items() if on}
    except Exception:
        pass
    return None


def refresh_models():
    """Убрать из меню модели, к которым у ключа нет доступа (иначе провайдер отвечает 403)."""
    changed = False
    for p in list(cfg.get("providers", {}).values()):
        ok = allowed_models(p)
        if ok is None:
            continue
        full = list(dict.fromkeys((p.get("models") or []) + p.get("hidden", [])
                                  + (REFORMBOSS_MODELS if "reformboss" in (p.get("base_url") or "") else [])))
        keep = [m for m in full if m in ok] or full
        hidden = [m for m in full if m not in keep]
        if keep != p.get("models") or hidden != p.get("hidden", []):
            p["models"], p["hidden"], changed = keep, hidden, True
    if changed:
        cur = cfg["providers"][cfg["provider"]]["models"]
        if cfg.get("model") not in cur:
            cfg["model"] = cur[0]
        if cfg.get("fast_model") and cfg["fast_model"] not in cur:
            cfg["fast_model"] = None
        save_cfg()


OWNER = int(os.environ.get("OWNER_ID") or cfg.get("owner") or 0)
CHANNEL = os.environ.get("CHANNEL_ID") or cfg.get("channel") or ""
fs = TgFS(TOKEN, CHANNEL or 0, WS, os.path.join(HERE, "index.json"))
fs_lock = threading.Lock()
draft_ids = itertools.count(int(time.time()) % 1_000_000)
runs = {}       # draft_id -> {"proc", "stopped", "chat", "kind" (claude|fast), "title", "started", "st", "agents"}
live = {}       # chat -> {"did", "agent"}: какую задачу (и какого агента) сейчас транслировать черновиком
polls = {}      # poll_id -> {"chat", "q", "opts"}
REMOTE_JOBS = {}  # job -> сведения о задаче на GitHub (переживают перезапуск бота)
JOBS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "remote_jobs.json")
waiting = {}    # что бот ждёт от владельца текстом: "add_provider"
ecc_cmds = {}   # имя команды ECC -> описание
media_buf = {}  # media_group_id -> собранные файлы


def save_cfg():
    json.dump(cfg, open(CFG_PATH, "w"), ensure_ascii=False, indent=1)


def tg(method, **data):
    try:
        r = requests.post(API + method, json=data, timeout=60).json()
    except requests.RequestException as e:
        return {"ok": False, "description": str(e)}
    res = r.get("result")
    if r.get("ok") and method.startswith("send") and isinstance(res, dict) and res.get("message_id") \
            and str(data.get("chat_id")) != str(CHANNEL):
        tgctl.log_msg(data.get("chat_id"), res["message_id"], "bot", data.get("text") or "[" + method[4:] + "]")
    return r


CHAT_DEFAULT = {"session": None, "history": [], "access": "owner", "reply": "mention", "trust": False,
                "title": "", "type": ""}


def C(chat):
    """Настройки и сессии конкретного чата (личка, группа, канал)."""
    ch = cfg.setdefault("chats", {}).setdefault(str(chat), {})
    for k, v in CHAT_DEFAULT.items():
        ch.setdefault(k, list(v) if isinstance(v, list) else v)
    return ch


def chat_prompt(chat, value=None):
    p = os.path.join(tgctl.PROMPT_DIR, f"{chat}.txt")
    if value is not None:
        os.makedirs(tgctl.PROMPT_DIR, exist_ok=True)
        if value:
            open(p, "w", encoding="utf-8").write(value)
        elif os.path.exists(p):
            os.remove(p)
    return open(p, encoding="utf-8").read().strip() if os.path.exists(p) else ""


def session_file(sid):
    return glob.glob(os.path.join(CLAUDE_DIR, "projects", "*", f"{sid}.jsonl"))


def delete_session(chat, sid):
    for f in session_file(sid):
        try:
            os.remove(f)
        except OSError:
            pass
    ch = C(chat)
    ch["history"] = [h for h in ch["history"] if h["id"] != sid]
    if ch["session"] == sid:
        ch["session"] = None
    save_cfg()


def clear_chat(chat):
    """Удалить сообщения чата (за 48 ч, что успел записать бот) и текущую сессию."""
    fast.clear_hist(HERE, chat)
    p = os.path.join(tgctl.LOG_DIR, f"{chat}.jsonl")
    ids = []
    if os.path.exists(p):
        now = time.time()
        for line in open(p, encoding="utf-8"):
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if now - e.get("ts", 0) < 47 * 3600 and isinstance(e.get("id"), int):
                ids.append(e["id"])
        os.remove(p)
    for i in range(0, len(ids), 100):
        tg("deleteMessages", chat_id=chat, message_ids=ids[i:i + 100])
    sid = C(chat)["session"]
    if sid:
        delete_session(chat, sid)
    return len(ids)


# ---------------- форматирование ----------------
def md_to_html(md):
    """Минимальный Markdown -> HTML: ```код```, `код`, **жирный**, заголовки."""
    out, parts = [], re.split(r"```(\w*)\n?(.*?)```", md, flags=re.S)
    for i in range(0, len(parts), 3):
        t = html.escape(parts[i])
        t = re.sub(r"`([^`\n]+)`", r"<code>\1</code>", t)
        t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
        t = re.sub(r"(?m)^#{1,6}\s*(.+)$", r"<b>\1</b>", t)
        out.append(t)
        if i + 2 < len(parts):
            lang = parts[i + 1]
            cls = f' class="language-{lang}"' if lang else ""
            out.append(f"<pre><code{cls}>{html.escape(parts[i + 2])}</code></pre>")
    return "".join(out).strip()


def chunks(text, n=3500):
    while text:
        cut = text.rfind("\n", 0, n) if len(text) > n else len(text)
        cut = cut if cut > 0 else n
        yield text[:cut]
        text = text[cut:].lstrip("\n")


def step_label(name, inp):
    arg = inp.get("command") or inp.get("file_path") or inp.get("pattern") or inp.get("url") \
        or inp.get("description") or inp.get("skill") or ""
    arg = os.path.relpath(arg, WS) if arg.startswith(WS) else arg
    arg = (arg[:48] + "…") if len(arg) > 48 else arg
    return f"{TOOL_ICONS.get(name, '🔧')} {name} {arg}".strip()


# ---------------- запуск Claude Code ----------------
def claude_env():
    env = dict(os.environ)
    env.update(WORKSPACE=WS, PATH=HERE + os.pathsep + env.get("PATH", ""))
    p = cfg["providers"][cfg["provider"]]
    if p.get("base_url"):
        env["ANTHROPIC_BASE_URL"] = p["base_url"]
        env["ANTHROPIC_AUTH_TOKEN"] = p["token"]
        env.pop("ANTHROPIC_API_KEY", None)
        env["ANTHROPIC_MODEL"] = cfg["model"]
        env["ANTHROPIC_SMALL_FAST_MODEL"] = cfg["model"]
        for k in ("ANTHROPIC_DEFAULT_HAIKU_MODEL", "ANTHROPIC_DEFAULT_SONNET_MODEL",
                  "ANTHROPIC_DEFAULT_OPUS_MODEL", "CLAUDE_CODE_SUBAGENT_MODEL"):
            env[k] = cfg["model"]  # агенты ECC просят sonnet/opus — отдаём модель провайдера
    elif p.get("token"):
        env["ANTHROPIC_API_KEY"] = p["token"]
    g = gen_cfg()
    env["MEDIA_IMAGE"], env["MEDIA_VIDEO"] = g["image"], g["video"]
    return env


# ---------------- генерация картинок и видео ----------------
GEN_IMAGE = [  # (провайдер|модель, подпись)
    ("puter|gpt-image-2.5-flare", "GPT Image 2.5 Flare"), ("puter|gpt-image-2.5-sunburst", "GPT Image 2.5 Sunburst"),
    ("puter|gpt-image-2", "GPT Image 2"), ("puter|gemini-nano-banana-2.1", "🍌 Nano Banana 2.1"),
    ("puter|gemini-3-pro-image", "🍌 Nano Banana Pro"), ("puter|gemini-3.1-flash-image", "🍌 Nano Banana 2"),
    ("puter|gemini-3.1-flash-lite-image", "🍌 Nano Banana 2 Lite"), ("hf|flux-schnell", "FLUX schnell"),
    ("horde|Flux.1-Schnell fp8 (Compact)", "FLUX schnell 2"), ("horde|Juggernaut XL", "Juggernaut XL"),
    ("horde|WAI-NSFW-illustrious-SDXL", "‼️ WAI аниме"),
    ("horde|ICBINP - I Can't Believe It's Not Photography", "‼️ ICBINP"),
    ("hf|wai-nsfw", "‼️ WAI (HF)"), ("horde|CyberRealistic Pony", "‼️ CyberRealistic Pony"), ("horde|WAI-ANI-NSFW-PONYXL", "‼️ WAI Pony XL"),
    ("auto|", "🔀 Авто (что доступно)")]
GEN_VIDEO = [
    ("hf|ltx2", "LTX-2.3"), ("hf|wan", "Wan 2.2"), ("hf|nsfw", "‼️ Wan 2.2"),
    ("puter|dreamina-seedance-2-5-260628", "Seedance 2.5"), ("puter|wan2.7-t2v", "Wan 2.7"), ("auto|", "🔀 Авто")]
GEN_MODES = {"chat": "💬 Обычный", "image": "🖼 Каждое сообщение — фото", "video": "🎬 Каждое сообщение — видео"}


def gen_cfg():
    g = cfg.setdefault("gen", {})
    g.setdefault("image", "puter|gemini-nano-banana-2.1" if os.environ.get("PUTER_TOKEN") else "hf|flux-schnell")
    if g.get("video") in (None, "hf|ltx"):
        g["video"] = "hf|ltx2"
    g.setdefault("mode", "chat")
    return g


def gen_label(kind, v):
    return dict(GEN_IMAGE if kind == "image" else GEN_VIDEO).get(v, v)


def menu_gen():
    g = gen_cfg()
    text = (f"🎨 <b>Генерация</b>\nФото: <code>{html.escape(gen_label('image', g['image']))}</code>"
            f"\nВидео: <code>{html.escape(gen_label('video', g['video']))}</code>\nРежим: {GEN_MODES[g['mode']]}\n\n"
            "Команды: /image промпт · /video промпт. Фото с подписью /video текст — оживит его, "
            "/edit текст — отредактирует. ‼️ — без цензуры.")
    rows = [[(("✅ " if k == g["mode"] else "") + v, "gmo:" + k)] for k, v in GEN_MODES.items()]
    rows += [[("🖼 Модель фото", "gim"), ("🎬 Модель видео", "gvm")], [("⬅️ Назад", "main")]]
    return text, kb(rows)


def menu_gen_models(kind):
    g, lst = gen_cfg(), (GEN_IMAGE if kind == "image" else GEN_VIDEO)
    rows, row = [], []
    for i, (v, lbl) in enumerate(lst):
        row.append((("✅ " if v == g[kind] else "") + lbl, f"g{kind[0]}:{i}"))
        if len(row) == 2:
            rows.append(row); row = []
    if row:
        rows.append(row)
    return ("Выбери модель для " + ("фото" if kind == "image" else "видео") + ":"), kb(rows + [[("⬅️ Назад", "gen")]])


def run_gen(chat, kind, prompt, mid=None, images=None):
    """Сгенерировать фото/видео выбранной моделью и прислать."""
    import media
    g = gen_cfg()
    prov, _, model = g[kind].partition("|")
    t0 = time.time()
    tg("sendChatAction", chat_id=chat, action="upload_photo" if kind == "image" else "upload_video")
    st = tg("sendMessage", chat_id=chat, text=("🎨 Рисую" if kind == "image" else "🎬 Снимаю видео") +
            f" · {gen_label(kind, g[kind])}…", **({"reply_parameters": {"message_id": mid, "allow_sending_without_reply": True}} if mid else {}))
    smid = (st.get("result") or {}).get("message_id")
    stop = threading.Event()

    def typing():
        while not stop.wait(4.5):
            tg("sendChatAction", chat_id=chat, action="upload_photo" if kind == "image" else "upload_video")
    threading.Thread(target=typing, daemon=True).start()
    head = ("🎨 Рисую" if kind == "image" else "🎬 Снимаю видео") + f" · {gen_label(kind, g[kind])}"
    last = [0.0, ""]

    def progress(t):  # показываем место в очереди Horde, не чаще раза в 5 с
        if smid and t != last[1] and time.time() - last[0] > 5:
            last[:] = [time.time(), t]
            tg("editMessageText", chat_id=chat, message_id=smid, text=f"{head}\n⏳ {t}")
    media.PROGRESS = progress
    try:
        if kind == "image":
            if images and prov == "hf":  # FLUX на HF не редактирует — берём Nano Banana / Horde img2img
                prov, model = ("puter", "gemini-nano-banana-2.1") if os.environ.get("PUTER_TOKEN") else ("horde", "")
            path = media.image(prompt, prov or "auto", model or None, nsfw=prov == "horde", images=images)
        else:
            if images and prov == "puter":  # у Puter на видео нет бесплатного баланса
                prov, model = "hf", "wan"
            path = media.video(prompt, images[0] if images else None, prov or "auto", model or None)
        md = f"![{md_esc(prompt[:80])}](file:{path})\n\n<footer>{'🖼' if kind == 'image' else '🎬'} " \
             f"{html.escape(gen_label(kind, g[kind]))}  •  ⏱ {fmt_dur(time.time() - t0)}</footer>"
        tgctl.rich_send(chat, md, WS, reply_to=mid)
    except Exception as e:
        tg("sendMessage", chat_id=chat, text=f"⚠️ Не получилось: {str(e)[:800]}\nСменить модель: /gen")
    finally:
        stop.set()
        media.PROGRESS = None
        if smid:
            tg("deleteMessage", chat_id=chat, message_id=smid)


QUOTA_PER_USD = 500000  # new-api / one-api: 500 000 единиц квоты = $1
last_agents = {}        # агенты последней задачи — для /agents


def provider_balance(p=None):
    """Баланс у провайдера (new-api/one-api). 1) баланс аккаунта по системному токену (access + uid),
    2) остаток ключа /api/usage/token/, 3) хотя бы потраченное /v1/dashboard/billing/usage. None, если не умеет."""
    p = p or cfg["providers"][cfg["provider"]]
    if not p.get("base_url") or not p.get("token"):
        return None
    base, out = p["base_url"].rstrip("/"), {}
    if p.get("access") and p.get("uid"):
        for auth in (p["access"], "Bearer " + p["access"]):
            try:
                d = requests.get(base + "/api/user/self", timeout=10,
                                 headers={"Authorization": auth, "New-Api-User": str(p["uid"]),
                                          "Veloera-User": str(p["uid"])}).json()
                if d.get("success") and d.get("data"):
                    u = d["data"]
                    return {"left": u.get("quota", 0) / QUOTA_PER_USD, "used": u.get("used_quota", 0) / QUOTA_PER_USD,
                            "unlimited": False, "account": True}
            except Exception:
                pass
    h = {"Authorization": "Bearer " + p["token"]}
    try:
        d = requests.get(base + "/api/usage/token/", timeout=10, headers=h).json().get("data") or {}
        if "total_available" in d:
            out = {"left": d["total_available"] / QUOTA_PER_USD, "used": d.get("total_used", 0) / QUOTA_PER_USD,
                   "unlimited": d.get("unlimited_quota", False)}
            if not out["unlimited"]:
                return out
    except Exception:
        pass
    try:
        u = requests.get(base + "/v1/dashboard/billing/usage", timeout=10, headers=h).json()
        if "total_usage" in u:
            out = {"left": None, "used": u["total_usage"] / 100, "unlimited": True}
    except Exception:
        pass
    return out or None


def fmt_bal(b):
    if not b:
        return "не узнать"
    left = f"${b['left']:.2f}" if b.get("left") is not None and not b.get("unlimited") else "остаток не виден"
    return f"{left} · потрачено ${b.get('used', 0):.2f}"


def balances_text():
    lines = ["💰 <b>Балансы провайдеров</b>"]
    res = {}
    def one(n, p):
        res[n] = provider_balance(p)
    ts = [threading.Thread(target=one, args=(n, p)) for n, p in cfg.get("providers", {}).items()]
    [t.start() for t in ts]; [t.join(20) for t in ts]
    for n in cfg.get("providers", {}):
        mark = "▶️ " if n == cfg.get("provider") else ""
        lines.append(f"{mark}<b>{html.escape(n)}</b>: {fmt_bal(res.get(n))}")
    lines.append("\nЕсли «остаток не виден» — у ключа безлимит; добавь PROV_ИМЯ_ACCESS и PROV_ИМЯ_UID "
                 "(системный токен и ID из профиля сайта), тогда будет виден баланс аккаунта.")
    return "\n".join(lines)


def fmt_k(n):
    return f"{n / 1000:.1f}k" if n >= 1000 else str(n)


def fmt_dur(sec):
    """45 с · 3 мин 05 с · 1 ч 02 мин 05 с"""
    sec = int(sec)
    if sec < 60:
        return f"{sec} с"
    if sec < 3600:
        return f"{sec // 60} мин {sec % 60:02d} с"
    return f"{sec // 3600} ч {sec % 3600 // 60:02d} мин {sec % 60:02d} с"


SPIN_ICONS = "✻✢✳✶✽✺"
SPIN_WORDS = ["Размышляю", "Колдую", "Прикидываю", "Соображаю", "Вычисляю", "Обдумываю", "Шаманю", "Мастерю",
              "Кумекаю", "Плету код", "Варю идеи", "Разбираюсь", "Копаю глубже", "Собираю пазл", "Шлифую",
              "Настраиваю", "Сверяю", "Творю", "Сочиняю", "Нащупываю", "Распутываю", "Взвешиваю", "Перебираю",
              "Колдую над деталями", "Складываю", "Довожу до ума"]


def spin(seed):
    """Как в Claude Code: значок и слово меняются каждые несколько секунд."""
    n = int(time.time() // 4)
    rnd = random.Random(n * 7919 + seed)
    return f"{SPIN_ICONS[n % len(SPIN_ICONS)]} {rnd.choice(SPIN_WORDS)}…"


def msg_tokens(m):
    u = m.get("usage") or {}
    return (u.get("input_tokens", 0) + u.get("cache_read_input_tokens", 0) + u.get("cache_creation_input_tokens", 0),
            u.get("output_tokens", 0))


POLL_HINT = ("Если для продолжения нужен выбор пользователя из вариантов, не задавай вопрос просто текстом и не жди: "
             "закончи ответ блоком\n```poll\nКороткий вопрос?\n- Вариант 1\n- Вариант 2\n```\n(2–10 коротких "
             "вариантов, до 100 символов). Бот покажет его как опрос Telegram; выбор или свой вариант пользователя "
             "придёт следующим сообщением. Инструмент AskUserQuestion не используй.")


def extract_polls(text):
    """Вырезает блоки ```poll из ответа. Возвращает (текст, [(вопрос, [варианты])])."""
    found = []

    def repl(m):
        lines = [l.strip() for l in m.group(1).strip().splitlines() if l.strip()]
        q = next((l for l in lines if not l.startswith(("-", "*"))), "Выбери вариант")
        opts = [re.sub(r"^[-*]\s*(\[.\]\s*)?", "", l)[:100] for l in lines if l.startswith(("-", "*"))]
        opts = [o for o in opts if o][:10]
        if len(opts) >= 2:
            found.append((q[:300], opts))
            return ""
        return m.group(0)
    text = re.sub(r"```poll\s*\n(.*?)```", repl, text or "", flags=re.S)
    return text.strip(), found


def send_polls(chat, found, kind):
    for q, opts in found:
        r = tg("sendPoll", chat_id=chat, question=q, options=[{"text": o} for o in opts],
               is_anonymous=False, allows_multiple_answers=False)
        if not r.get("ok"):  # например, канал: неанонимные опросы нельзя
            r = tg("sendPoll", chat_id=chat, question=q, options=[{"text": o} for o in opts])
        if r.get("ok"):
            polls[r["result"]["poll"]["id"]] = {"chat": chat, "q": q, "opts": opts, "kind": kind}
    if found and kind == "claude":
        C(chat)["await_claude"] = True  # свой вариант текстом тоже уйдёт агенту, а не в быстрый режим
        save_cfg()


def on_poll_answer(pa):
    p = polls.get(pa.get("poll_id"))
    uid = (pa.get("user") or {}).get("id")
    if not p or not pa.get("option_ids"):
        return
    if uid != OWNER and C(p["chat"]).get("access") != "all":
        return
    choice = ", ".join(p["opts"][i] for i in pa["option_ids"] if i < len(p["opts"]))
    who = "владелец" if uid == OWNER else ((pa.get("user") or {}).get("first_name") or "участник")
    live_off(p["chat"])
    start_task(p["chat"], f"Мой выбор в опросе «{p['q']}»: {choice}", who=who, force_claude=p["kind"] == "claude")


def live_off(chat):
    live.pop(chat, None)


def live_on(chat, did, agent=None):
    live[chat] = {"did": did, "agent": agent}


def focused(chat, did):
    l = live.get(chat)
    return bool(l and l["did"] == did)


def active_claude(chat=None):
    return [(d, r) for d, r in list(runs.items())
            if r.get("kind") == "claude" and not r["stopped"] and (chat is None or r["chat"] == chat)]


def runs_summary(chat):
    """Коротко о работающих агентах — для быстрого режима, чтобы он мог ответить «как там задача»."""
    out = []
    for d, r in active_claude(chat):
        st = r["st"]
        out.append(f"- Задача «{r['title']}», идёт {fmt_dur(time.time() - r['started'])}, шагов {len(st['steps'])}, "
                   f"токенов {fmt_k(st['tin'] + st['tout'])}. Последние шаги: " + "; ".join(st["steps"][-8:]))
        for a in list(r["agents"].values())[-4:]:
            out.append(f"  - агент {a['name']}: {a['last'][:120] or 'работает'}")
        if st["text"].strip():
            out.append("  Сейчас пишет: " + st["text"].strip()[-400:])
    return "\n".join(out)


def save_jobs():
    try:
        json.dump(REMOTE_JOBS, open(JOBS_PATH, "w"), ensure_ascii=False)
    except Exception as e:
        print("save jobs:", e, flush=True)


def bq(title, body, limit=3300):
    """Сворачиваемая цитата: в чате видно 3 строки, по нажатию раскрывается."""
    body = body if len(body) <= limit else "…" + body[-limit:]
    return f"<blockquote expandable>{title}\n{html.escape(body)}</blockquote>"


def agents_md():
    return "\n\n".join(details(f"🧩 {a['name']}", "\n\n".join(a["log"])[-6000:] or "—") for a in last_agents.values())


def system_hint(chat, guest, who, mid):
    ch = C(chat)
    where = "личный чат с владельцем" if int(chat) > 0 else f"{ch['type']} «{ch['title']}»"
    h = [f"Ты — Telegram-бот @{BOT_USERNAME} на базе Claude Code. Сейчас ты в чате: {where} (chat_id {chat}). "
         f"Пишет: {who} (message_id {mid}). Отвечай по-русски, если пользователь не пишет на другом языке.",
         "Твой ответ уйдёт в чат rich-сообщением в формате Markdown (GFM): можно заголовки #, таблицы, "
         "блоки кода с языком, формулы $x^2$ и $$...$$, списки задач, ==выделение==, ||спойлер||, "
         "<details><summary>Заголовок</summary>...</details> для сворачиваемых блоков. "
         "Оформляй ответы, когда это помогает читать."]
    if not guest:
        h += ["Рабочая папка проекта — текущая директория, файлы читай и правь здесь; можно создавать и удалять "
              "файлы и папки — изменения сами уйдут в канал-хранилище. Тяжёлые команды (установка пакетов, запуск, "
              'тесты, сборка) выполняй через Bash: rexec "команда" — на удалённой машине с копией папки.',
              "Сайты и веб-приложения НЕ запускай на этой машине и не поднимай туннели (cloudflared, ngrok) и не "
              "давай IP-адреса. Статический сайт: положи в sites/<имя>/ (index.html и файлы) и выполни "
              f"rexec publish — ссылка будет {os.environ.get('REXEC_URL', '').rstrip('/')}/s/<имя>/ . "
              "Сервер с бэкендом: запусти в фоне на Render, например "
              'rexec "cd sites/app && nohup python3 -m http.server 8000 > app.log 2>&1 &", порт 3000–9999 — '
              f"ссылка {os.environ.get('REXEC_URL', '').rstrip('/')}/p/8000/ (пути в приложении делай относительными). "
              "Render — это Linux с bash; rexec выполняет команду в bash. Он может уснуть — тогда просто снова rexec publish.",
              "Графики и картинки: построй PNG (например matplotlib через rexec или локально) в папке проекта "
              "и вставь в ответ строкой ![подпись](file:путь/к/файлу.png) — он прикрепится к сообщению.",
              "Чатом управляешь через Bash-команду tgctl: tgctl history 30 (последние сообщения с id), "
              'tgctl send "markdown", tgctl photo путь, tgctl file путь, tgctl pin ID, tgctl unpin ID|all, '
              'tgctl delete ID..., tgctl edit ID "текст", tgctl react ID 👍, tgctl prompt "постоянные инструкции '
              "для этого чата\", tgctl api МЕТОД '{json}'. В канал-хранилище ничего не отправляй — только файлы, "
              "их синхронизирует бот.",
              "Генерация картинок и видео — Bash-команда tgmedia (печатает путь к файлу, потом вставь в ответ "
              "![подпись](file:путь)): tgmedia image \"подробный промпт на английском\" [--model gpt-image-2.5-flare|"
              "gemini-nano-banana-2.1|gemini-3-pro-image|flux] [--nsfw] [--size 1024x1536]; tgmedia video \"промпт\" "
              "[--image картинка.png] [--seconds 3]; tgmedia models — список. Сам пиши хорошие детальные промпты. "
              "Генерация занимает от 10 с до нескольких минут.",
              "Настоящий браузер Chromium в облаке — Bash-команда tgbrowser: tgbrowser open URL (владелец сразу получает "
              "ссылку и смотрит вживую), tgbrowser read (текст и пронумерованные элементы), tgbrowser click N, "
              "tgbrowser type N \"текст\" --enter, tgbrowser scroll, tgbrowser shot, tgbrowser eval \"JS\", "
              "tgbrowser close. Входы и куки сохраняются между запусками. Используй, когда нужен JS-сайт, вход в "
              "аккаунт, клики и формы. В конце работы — tgbrowser close.",
              "Навыки: ~/.claude/skills. По просьбе или когда задача повторяется — создай навык "
              "~/.claude/skills/<имя>/SKILL.md (frontmatter name, description, дальше инструкция). "
              "Новая команда бота: ~/.claude/commands/<имя>.md (frontmatter description, дальше промпт; "
              "$ARGUMENTS — аргументы) — бот сам добавит её в меню как /<имя>."]
        h.append(POLL_HINT)
    else:
        h.append("Это гость: доступа к серверу и файлам у тебя нет, просто отвечай в чате.")
    p = chat_prompt(chat)
    if p:
        h.append("Инструкции владельца для этого чата: " + p)
    return "\n".join(h)


INJ_MARK = "📨 Владелец дописал во время работы:"


def user_msg(text):
    return {"type": "user", "message": {"role": "user", "content": [{"type": "text", "text": text}]}}


def _write_stdin(proc, obj):
    try:
        proc.stdin.write(json.dumps(obj, ensure_ascii=False) + "\n")
        proc.stdin.flush()
        return True
    except Exception:
        return False


def inject(chat, text, did=None):
    """Передать уточнение работающему агенту Claude Code (последнему в чате). Возвращает название задачи или None."""
    act = [(d, r) for d, r in active_claude(chat) if r.get("inject") and (did is None or d == did)]
    if not act:
        return None
    d, r = act[-1]
    if r["inject"](user_msg(f"{INJ_MARK}\n{text}\n(Учти это и продолжай задачу.)")):
        r["inj_texts"].append(text)
        r["st"]["steps"].append("📨 " + re.sub(r"\s+", " ", text)[:60])
        r["st"]["dirty"] = True
        return r["title"]
    return None


def run_claude(chat_id, prompt, guest=False, who="владелец", mid=None, attach=None):
    did = next(draft_ids)
    started = attach["started"] if attach else time.time()
    st = {"steps": [], "text": "", "thinking": "", "result": "", "error": "", "dirty": True, "res": {},
          "tin": 0, "tout": 0, "msgs": {}, "tok_at_step": 0, "sid": None}
    agents = {}  # tool_use_id агента -> {"name", "log": [], "last": "", "tin", "tout"}
    ch = C(chat_id)
    private = int(chat_id) > 0
    bal0 = provider_balance()
    title = attach["title"] if attach else re.sub(r"\s+", " ", prompt.split("\n\nПриложены файлы")[0])[:40]
    parallel = bool(active_claude(chat_id))  # уже идёт задача в этом чате — новая работает в отдельной сессии
    resume = None if parallel else ch["session"]
    first_text = prompt
    cmd = [CLAUDE, "-p", "--input-format", "stream-json", "--replay-user-messages", "--output-format", "stream-json", "--verbose",
           "--include-partial-messages", "--forward-subagent-text",
           "--model", cfg["model"], "--append-system-prompt", system_hint(chat_id, guest, who, mid)]
    mode = cfg.get("mode", "bypass")
    if guest:
        cmd += ["--allowedTools", "WebSearch WebFetch",
                "--disallowedTools", "Bash Edit Write MultiEdit NotebookEdit Read Grep Glob Task Agent"]
    else:
        cmd += ["--dangerously-skip-permissions"] if mode == "bypass" else ["--permission-mode", mode]
        cmd += ["--disallowedTools", "AskUserQuestion"]
    if cfg.get("effort") == "ultrathink":  # максимум размышлений: effort max + ключевое слово ultrathink
        cmd += ["--effort", "max"]
        first_text = "ultrathink. " + first_text
    elif cfg.get("effort"):
        cmd += ["--effort", cfg["effort"]]
    new_session = attach["new_session"] if attach else not resume
    if resume:
        cmd += ["--resume", resume]
    env = claude_env()
    env.update(TG_CHAT=str(chat_id), TG_MSG=str(mid or ""), TG_STORAGE=str(CHANNEL))
    # Память: на 512 МБ Claude Code (node) мог съесть всё, и Wispbyte гасил весь сервер.
    # Ограничиваем кучу node, а ядру говорим убивать при нехватке в первую очередь Claude, а не бота.
    heap = os.environ.get("CLAUDE_HEAP_MB", "320")
    if "max-old-space-size" not in env.get("NODE_OPTIONS", ""):
        env["NODE_OPTIONS"] = (env.get("NODE_OPTIONS", "") + f" --max-old-space-size={heap}").strip()
    first = user_msg(first_text)
    runs[did] = {"proc": None, "stopped": False, "chat": chat_id, "kind": "claude", "title": title,
                 "started": started, "st": st, "agents": agents, "inject": None, "inj_texts": []}
    st["ack"] = 0
    if private:
        live_on(chat_id, did)  # новая задача сразу транслируется
    try:
        if attach:
            proc = RemoteProc.attach(attach)
        elif remote_on():
            if private:
                tg("sendRichMessageDraft", chat_id=chat_id, draft_id=did, can_stop=True,
                   rich_message={"markdown": "<tg-thinking>☁️ Отправляю задачу на GitHub…</tg-thinking>"})
            proc = RemoteProc(cmd, env, resume, first)
            REMOTE_JOBS[proc.job] = {
                "job": proc.job, "chat": chat_id, "prompt": prompt[:4000], "guest": guest, "who": who, "mid": mid,
                "title": title, "started": started, "new_session": new_session, "sent_ws": sorted(proc.sent_ws)}
            save_jobs()
            if runs[did]["stopped"]:  # нажали стоп, пока отправляли
                proc.stop()
                runs.pop(did, None)
                tg("sendMessage", chat_id=chat_id, text="⏹ Остановлено.")
                return
        else:
            proc = subprocess.Popen(cmd, cwd=WS, env=env, stdout=subprocess.PIPE, stdin=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True, bufsize=1, start_new_session=True,
                                    preexec_fn=oom_first)
            proc.stdin.write(json.dumps(first, ensure_ascii=False) + "\n")
            proc.stdin.flush()
    except FileNotFoundError:
        runs.pop(did, None)
        tg("sendMessage", chat_id=chat_id, text=f"Не найден {CLAUDE}. Проверь CLAUDE_BIN.")
        return
    except Exception as e:
        runs.pop(did, None)
        tg("sendMessage", chat_id=chat_id, text=f"Не удалось запустить Claude: {e}")
        return
    runs[did]["proc"] = proc
    runs[did]["inject"] = proc.send if isinstance(proc, RemoteProc) else (lambda obj: _write_stdin(proc, obj))

    def draft_md():
        sec = time.time() - started
        l = live.get(chat_id) or {}
        aid = l.get("agent")
        if aid and aid in agents:  # смотрим внутрь агента
            a = agents[aid]
            lines = [f"{spin(did)} · 🧩 {a['name']} · {fmt_dur(sec)} · 🔤 {fmt_k(a['tin'])} → {fmt_k(a['tout'])}"]
            lines += [x.splitlines()[0][:150] for x in a["log"][-8:] if x.strip()]
            body = a["log"][-1] if a["log"] and not a["log"][-1].startswith(("→", "💭")) else ""
            status = "<br>".join(html.escape(x) for x in lines)
            return f"<tg-thinking>{status}</tg-thinking>\n\n" + safe_tail(body, 2500)
        lines = [f"{spin(did)} · {fmt_dur(sec)} · шагов {len(st['steps'])} · 🔤 {fmt_k(st['tin'])} → {fmt_k(st['tout'])}"]
        lines += st["steps"][-5:]
        if st.get("phase") and not st["steps"] and not st["text"]:
            lines.append("☁️ " + st["phase"])
        for a in list(agents.values())[-3:]:
            lines.append(f"🧩 {a['name']}: {a['last'][:70] or 'работает…'}")
        if st["thinking"] and not st["text"]:
            lines.append(st["thinking"][-300:])
        others = len(active_claude(chat_id)) - 1
        if others > 0:
            lines.append(f"📡 ещё задач: {others} — /live")
        status = "<br>".join(html.escape(x) for x in lines)
        return f"<tg-thinking>{status}</tg-thinking>\n\n" + safe_tail(st["text"])

    def drafter():
        # Плавное появление: частые обновления, пока идёт текст; не реже раза в 3 с (черновик живёт 30 с)
        last = 0
        while proc.poll() is None and not runs[did]["stopped"] and not st.get("done"):
            if not private:
                tg("sendChatAction", chat_id=chat_id, action="typing")
                time.sleep(4)
                continue
            if not focused(chat_id, did):  # трансляция скрыта или смотрят другую задачу — черновик не шлём
                time.sleep(0.5)
                continue
            if (st["dirty"] and time.time() - last > 1.5) or time.time() - last > 3:
                st["dirty"] = False
                last = time.time()
                r = tg("sendRichMessageDraft", chat_id=chat_id, draft_id=did, can_stop=True,
                       rich_message={"markdown": draft_md()})
                if not r.get("ok") and "parse" in (r.get("description") or "").lower():
                    tg("sendRichMessageDraft", chat_id=chat_id, draft_id=did, can_stop=True,
                       rich_message={"html": "<tg-thinking>" + html.escape(st["steps"][-1] if st["steps"] else spin(did))
                                     + "</tg-thinking>"})
            time.sleep(0.5)

    threading.Thread(target=drafter, daemon=True).start()
    threading.Thread(target=cpu_throttle, args=(proc, runs[did]), daemon=True).start()
    errlines = []

    for line in proc.stdout:
        try:
            ev = json.loads(line)
        except ValueError:
            errlines.append(line)
            continue
        t, pid = ev.get("type"), ev.get("parent_tool_use_id")
        if t == "_status":
            st["phase"] = ev.get("text", "")
            st["dirty"] = True
            continue
        if t == "system" and ev.get("session_id") and not pid:
            st["sid"] = ev["session_id"]
        if t == "user" and not pid and INJ_MARK in json.dumps(ev.get("message", {}), ensure_ascii=False):
            st["ack"] += 1  # уточнение владельца дошло до модели
            st["steps"].append("📨 уточнение получено")
            st["dirty"] = True
            continue
        if t == "assistant":  # токены: по одному разу на сообщение модели
            m = ev.get("message", {})
            if m.get("id") and m.get("usage"):
                tin, tout = msg_tokens(m)
                tgt = agents.setdefault(pid, {"name": "агент", "log": [], "last": "", "tin": 0, "tout": 0}) \
                    if pid else st
                prev = st["msgs"].get(m["id"], (0, 0))
                tgt["tin"] += tin - prev[0]; tgt["tout"] += tout - prev[1]
                if pid:
                    st["tin"] += tin - prev[0]; st["tout"] += tout - prev[1]
                st["msgs"][m["id"]] = (tin, tout)
        if t == "stream_event" and not pid:
            e = ev.get("event", {})
            if e.get("type") == "content_block_delta":
                d = e.get("delta", {})
                if d.get("type") == "text_delta":
                    st["text"] += d.get("text", "")
                    st["dirty"] = True
                elif d.get("type") == "thinking_delta":
                    st["thinking"] += d.get("thinking", "")
                    st["dirty"] = True
        elif t == "assistant" and pid:  # сообщение субагента
            a = agents.setdefault(pid, {"name": "агент", "log": [], "last": "", "tin": 0, "tout": 0})
            for c in ev.get("message", {}).get("content", []):
                if c.get("type") == "text" and c.get("text", "").strip():
                    a["log"].append(c["text"].strip())
                    a["last"] = c["text"].strip().splitlines()[0]
                elif c.get("type") == "thinking" and c.get("thinking"):
                    a["log"].append("💭 " + c["thinking"].strip()[:600])
                elif c.get("type") == "tool_use":
                    lbl = step_label(c.get("name", ""), c.get("input") or {})
                    a["log"].append("→ " + lbl)
                    a["last"] = lbl
            st["dirty"] = True
        elif t == "assistant":
            for c in ev.get("message", {}).get("content", []):
                if c.get("type") == "tool_use":
                    inp = c.get("input") or {}
                    if c.get("name") in ("Task", "Agent"):
                        name = inp.get("subagent_type") or "агент"
                        if inp.get("description"):
                            name += " · " + inp["description"][:40]
                        agents[c.get("id")] = {"name": name, "log": [], "last": "", "tin": 0, "tout": 0}
                    tok = st["tin"] + st["tout"]
                    delta, st["tok_at_step"] = tok - st["tok_at_step"], tok
                    st["steps"].append(step_label(c.get("name", ""), inp) + (f" · 🔤 +{fmt_k(delta)}" if delta > 0 else ""))
                    st["text"] = ""  # между шагами начинается новый текст
                    st["dirty"] = True
        elif t == "result":
            st["result"] = ev.get("result") or st["text"]
            st["res"] = ev
            if ev.get("session_id"):
                ch["session"] = ev["session_id"]
                if new_session and ch.get("temp"):  # временная сессия: не сохраняем, удалится при выходе
                    ch["temp_sid"] = ev["session_id"]
                elif new_session:
                    ch["history"] = ([{"id": ev["session_id"], "title": title, "ts": int(time.time())}]
                                     + [h for h in ch["history"] if h["id"] != ev["session_id"]])[:30]
                save_cfg()
            if ev.get("is_error"):
                st["error"] = ev.get("subtype", "error")
            time.sleep(1.5)  # вдруг как раз пришло уточнение
            if len(runs[did]["inj_texts"]) > st["ack"] and not runs[did]["stopped"]:
                # владелец дописал, модель ещё ответит — промежуточный ответ отправляем сразу
                if st["result"].strip():
                    tgctl.rich_send(chat_id, "**↪️ Промежуточный ответ**\n\n" + st["result"][:28000], WS,
                                    reply_to=None if private else mid)
                st["text"], st["result"] = "", ""
                continue
            if not isinstance(proc, RemoteProc):
                try:
                    proc.stdin.close()
                except Exception:
                    pass
            # Ответ готов. Дальше не ждём: фоновые процессы (сервер, туннель), запущенные моделью,
            # держат stdout открытым — из-за этого задача «не заканчивалась».
            st["done"] = True
            break
    try:
        proc.wait(timeout=15)
    except subprocess.TimeoutExpired:
        pass
    try:
        proc.stdout.close()
    except Exception:
        pass
    err = "".join(errlines)[-1500:]
    if proc.returncode in (-9, 137) and not st["result"]:
        err = ("Claude Code был убит из-за нехватки памяти на сервере. Бот работает. Попробуй ещё раз; "
               "тяжёлые команды (сборки, npm, pip, сервера) пусть выполняются через rexec на Render.\n" + err)
    elif "heap out of memory" in err.lower() and not st["result"]:
        err = "Claude Code упёрся в лимит памяти (CLAUDE_HEAP_MB). Начни новую сессию /new или увеличь лимит.\n" + err
    _r = runs.pop(did)
    stopped = _r["stopped"]
    unsent = _r["inj_texts"][st["ack"]:]
    lost = "No conversation found with session ID" in (err + str(st["result"]))
    if lost and resume and not stopped and not st.get("text"):
        # сессии нет (файл не вернулся с GitHub или удалён) — начинаем новую сессию и повторяем
        if ch["session"] == resume:
            ch["session"] = None
        ch["history"] = [h for h in ch["history"] if h["id"] != resume]
        save_cfg()
        if isinstance(proc, RemoteProc) and REMOTE_JOBS.pop(proc.job, None):
            save_jobs()
        tg("sendMessage", chat_id=chat_id, text="ℹ️ Прошлая сессия не нашлась — продолжаю в новой.")
        return run_claude(chat_id, prompt, guest, who, mid)
    if focused(chat_id, did):
        live_off(chat_id)
    if isinstance(proc, RemoteProc) and REMOTE_JOBS.pop(proc.job, None):
        save_jobs()
    if stopped and st.get("sid") and not parallel:  # остановили — продолжить можно в той же сессии
        ch["session"] = st["sid"]
    last_agents.clear()
    last_agents.update(agents)

    with fs_lock:
        try:
            added, removed = fs.sync()
        except Exception as e:
            added, removed = 0, 0
            err += f"\nСинхронизация с каналом: {e}"

    # ---- статистика: токены, время, кредиты
    sec = int(time.time() - started)
    res, usage = st["res"], st["res"].get("usage") or {}
    tin = usage.get("input_tokens", 0) + usage.get("cache_read_input_tokens", 0) + \
        usage.get("cache_creation_input_tokens", 0)
    tout = usage.get("output_tokens", 0)
    bal1 = provider_balance() if bal0 else None
    spent = round(bal0["left"] - bal1["left"], 4) if bal0 and bal1 else None
    cost = spent if spent is not None else res.get("total_cost_usd")
    stats = cfg.setdefault("stats", {"cost": 0.0, "in": 0, "out": 0, "runs": 0})
    stats["cost"] += cost or 0; stats["in"] += tin; stats["out"] += tout; stats["runs"] += 1
    cfg["last_run"] = {"cost": cost, "real": spent is not None, "in": tin, "out": tout, "sec": sec,
                       "turns": res.get("num_turns", 0), "left": bal1["left"] if bal1 else None}
    save_cfg()
    info = [f"⏱ {fmt_dur(sec)}", f"🔁 {res.get('num_turns', 0)}", f"🔤 {fmt_k(tin)} → {fmt_k(tout)}"]
    if cost is not None:
        info.append(f"💰 ${cost:.4f}" + ("" if spent is not None else "≈"))
    if bal1:
        info.append(f"💳 ${bal1['left']:.2f}")
    if added or removed:
        info.append(f"📁 +{added} −{removed}")
    footer = "<footer>" + "  •  ".join(info) + "</footer>"

    # ---- ход работы и агенты — сворачиваемыми блоками <details> (стрелочка)
    blocks = []
    if st["steps"] or st["thinking"].strip():
        body = "\n".join(f"{i + 1}. {md_esc(x)}" for i, x in enumerate(st["steps"][-60:]))
        if st["thinking"].strip():
            th = st["thinking"].strip()[-4000:]
            body += "\n\n**Размышления**\n\n" + "\n".join("> " + md_esc(l) for l in th.splitlines() if l.strip())
        blocks.append(details(f"🧠 Ход работы · {len(st['steps'])} шагов", body))
    for a in agents.values():
        if a["log"]:
            blocks.append(details(f"🧩 {a['name']} · 🔤 {fmt_k(a.get('tin', 0))} → {fmt_k(a.get('tout', 0))}",
                                  "\n\n".join(a["log"])[-4000:]))

    found = []
    if stopped:
        answer = "⏹ Остановлено."
    else:
        answer, found = extract_polls(st["result"])
        answer = answer or ("" if found else (f"Ошибка:\n```\n{err}\n```" if err else "(пустой ответ)"))
        if not answer:
            answer = "❓ Нужен твой выбор — ответь в опросе или напиши свой вариант."
    if parallel or len(active_claude(chat_id)):
        answer = f"**✅ Задача «{md_esc(title)}»**\n\n" + answer
    try:  # быстрый режим знает, чем закончилась задача агента
        fast.add_note(HERE, chat_id, f"(служебно) Агент Claude Code закончил задачу «{title}». Что он ответил?",
                      answer[:3000])
    except Exception:
        pass
    parts = list(chunks(answer, 28000))
    for i, part in enumerate(parts):
        md = ("\n\n".join(blocks) + "\n\n" if i == 0 and blocks else "") + part + \
            ("\n\n" + footer if i == len(parts) - 1 else "")
        tgctl.rich_send(chat_id, md, WS, reply_to=None if private else mid)
    send_polls(chat_id, found, "claude")
    if unsent and not stopped:  # уточнение не успело дойти до модели — продолжаем им в той же сессии
        tg("sendMessage", chat_id=chat_id, text="📨 Уточнение пришло после ответа — передаю его агенту следующей задачей.")
        threading.Thread(target=run_claude, args=(chat_id, "\n\n".join(unsent), guest, who, mid), daemon=True).start()
    if user_cmds_changed():
        register_commands()


# ---------------- Claude на машине GitHub Actions ----------------
# Бот остаётся на Wispbyte (лёгкий, 24/7), а сам Claude Code запускается на каждую задачу в GitHub Actions
# (4 ядра, 16 ГБ). Render-реле передаёт задачу и поток событий. Без GH_TOKEN — всё как раньше, локально.
GH_TOKEN = os.environ.get("GH_TOKEN", "")
GH_REPO = os.environ.get("GH_REPO", "null0null0xyz-max/Null")
GH_REF = os.environ.get("GH_REF", "main")
PACK_SKIP = {".git", "node_modules", "__pycache__", ".venv", "venv", ".cache"}
CLAUDE_SKIP = {"projects", "shell-snapshots", "statsig", "todos", "ide", "cache", "local", "downloads",
               "debug", "telemetry", "logs", "plugins"}
BROWSER_SKIP = {"Cache", "Code Cache", "GPUCache", "Service Worker", "GrShaderCache", "ShaderCache",
                "component_crx_cache", "__pycache__"}
ENV_PASS = ("ANTHROPIC_", "CLAUDE_CODE_", "TG_", "BOT_TOKEN", "REXEC_", "WORKSPACE", "MAX_THINKING", "MEDIA_",
            "PUTER_", "HF_TOKEN", "HORDE_", "STEEL_")


def remote_on():
    return bool(GH_TOKEN and os.environ.get("REXEC_URL")) and cfg.get("where", "github") == "github"


def _walk(top, skip):
    for root, dirs, files in os.walk(top):
        dirs[:] = [d for d in dirs if d not in skip]
        for n in files:
            yield os.path.join(root, n)


class RemoteProc:
    """Похоже на subprocess.Popen: .stdout (строки stream-json), poll(), wait(), returncode."""
    pid = None

    def __init__(self, cmd, env, session, first=None):
        self.url = os.environ["REXEC_URL"].rstrip("/")
        self.hdr = {"X-Token": os.environ.get("REXEC_TOKEN", "")}
        self.job = secrets.token_hex(16)
        self.returncode = None
        self.q = queue.Queue()
        self.done = threading.Event()
        self.applied = False
        self.stopped = False
        self.sent_ws = set()
        home = os.path.expanduser("~")
        payload = {"cmd": cmd, "home": home, "here": HERE, "ws": WS, "ecc_dir": ECC_DIR,
                   "extra_dirs": [os.path.join(HERE, "chatlog"), os.path.join(HERE, "chat_prompts"),
                                  os.path.join(HERE, "browser")],
                   "env": {k: v for k, v in env.items() if k.startswith(ENV_PASS)},
                   "tar": base64.b64encode(self._pack(home, session)).decode()}
        payload["env"]["WORKSPACE"] = WS
        sig = hmac.new(self.hdr["X-Token"].encode(), ("view:" + self.job).encode(), hashlib.sha256).hexdigest()[:20]
        payload["env"]["TG_VIEW_URL"] = f"{self.url}/v/{self.job}/{sig}"  # живой просмотр браузера модели
        if first:
            payload["first"], payload["marker"] = first, INJ_MARK
        for i in range(8):  # Render может просыпаться
            try:
                r = requests.post(f"{self.url}/relay/{self.job}/in", data=json.dumps(payload),
                                  headers=self.hdr, timeout=60)
                if r.ok:
                    break
                raise RuntimeError(f"реле: {r.status_code} {r.text[:200]}")
            except requests.RequestException:
                time.sleep(8)
        else:
            raise RuntimeError("Render-реле не отвечает")
        r = requests.post(f"https://api.github.com/repos/{GH_REPO}/actions/workflows/claude.yml/dispatches",
                          json={"ref": GH_REF, "inputs": {"job": self.job, "relay": self.url}}, timeout=30,
                          headers={"Authorization": "Bearer " + GH_TOKEN, "Accept": "application/vnd.github+json"})
        if r.status_code != 204:
            raise RuntimeError(f"GitHub не запустил задачу: {r.status_code} {r.text[:300]}")
        self.q.put(json.dumps({"type": "_status", "text": "жду машину GitHub"}) + "\n")
        self.stdout = self._lines()
        threading.Thread(target=self._poll, daemon=True).start()

    @classmethod
    def attach(cls, info):
        """Подключиться к задаче, которая уже идёт на GitHub (после перезапуска бота)."""
        self = cls.__new__(cls)
        self.url = os.environ["REXEC_URL"].rstrip("/")
        self.hdr = {"X-Token": os.environ.get("REXEC_TOKEN", "")}
        self.job = info["job"]
        self.returncode, self.applied, self.stopped = None, False, False
        self.q, self.done = queue.Queue(), threading.Event()
        self.sent_ws = set(info.get("sent_ws") or [])
        self.q.put(json.dumps({"type": "_status", "text": "переподключился к задаче на GitHub"}) + "\n")
        self.stdout = self._lines()
        threading.Thread(target=self._poll, daemon=True).start()
        return self

    def _pack(self, home, session):
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as t:
            def add(p):
                try:
                    if os.path.islink(p) or os.path.getsize(p) < 50_000_000:
                        t.add(p, arcname=p.lstrip("/"), recursive=False)
                except OSError:
                    pass
            for p in _walk(WS, PACK_SKIP):
                self.sent_ws.add(os.path.relpath(p, WS))
                add(p)
            cd = os.path.join(home, ".claude")
            for p in _walk(cd, CLAUDE_SKIP):
                add(p)
            if session:  # только нужная сессия, а не вся история
                proj = os.path.join(cd, "projects", re.sub(r"[^A-Za-z0-9]", "-", WS))
                for p in [os.path.join(proj, session + ".jsonl")] + list(_walk(os.path.join(proj, session), set())):
                    if os.path.exists(p):
                        add(p)
            for d in ("chatlog", "chat_prompts", "browser"):
                for p in _walk(os.path.join(HERE, d), BROWSER_SKIP):
                    add(p)
            if os.path.exists(os.path.join(home, ".claude.json")):
                add(os.path.join(home, ".claude.json"))
        return buf.getvalue()

    def _lines(self):
        while True:
            line = self.q.get()
            if line is None:
                return
            yield line

    def _poll(self):
        n, t0, started = 0, time.time(), False
        while not self.stopped:
            try:
                r = requests.get(f"{self.url}/relay/{self.job}/ev", params={"from": n}, headers=self.hdr, timeout=40)
                if r.status_code == 404:  # реле не знает задачу (Render перезапускался)
                    self.q.put("Реле потеряло задачу (Render перезапускался) — результат не получить.\n")
                    break
                j = r.json()
            except Exception:
                time.sleep(3)
                if time.time() - t0 > 6 * 3600:
                    break
                continue
            started = started or j.get("started")
            for line in j.get("lines", []):
                try:
                    ev = json.loads(line)
                except ValueError:
                    ev = {}
                if ev.get("type") == "_done":
                    self.returncode = ev.get("code", 0)
                    if ev.get("error"):
                        self.q.put(ev["error"] + "\n")
                    continue
                self.q.put(line + "\n")
            n = j.get("next", n)
            if j.get("done"):
                break
            if not started and time.time() - t0 > 300:
                self.q.put("GitHub Actions не взял задачу за 5 минут.\n")
                self.returncode = 1
                break
        if self.stopped:
            return
        if self.returncode is None:
            self.returncode = 1
        self.done.set()
        self.q.put(None)

    def poll(self):
        return self.returncode if self.done.is_set() else None

    def send(self, obj):
        """Уточнение владельца во время работы — через реле в stdin Claude на машине GitHub."""
        try:
            r = requests.post(f"{self.url}/relay/{self.job}/msg", data=json.dumps(obj, ensure_ascii=False).encode(),
                              headers=self.hdr, timeout=30)
            return r.ok
        except Exception:
            return False

    def wait(self, timeout=None):
        if self.stopped:
            return self.returncode
        self.done.wait(max(timeout or 0, 240))  # файлы возвращаются после ответа
        self._apply()
        return self.returncode

    def _apply(self):
        if self.applied or not self.done.is_set():
            return
        self.applied = True
        try:
            r = requests.get(f"{self.url}/relay/{self.job}/out", headers=self.hdr, timeout=120)
            if not r.content:
                return
            with tarfile.open(fileobj=io.BytesIO(r.content), mode="r:gz") as t:
                man = None
                members = []
                for m in t.getmembers():
                    if m.name == "__manifest__.json":
                        man = set(json.loads(t.extractfile(m).read()))
                    else:
                        members.append(m)
                t.extractall("/", members=members, filter="tar")
            if man is not None:  # удалённые Claude файлы удаляем и здесь
                for rel in self.sent_ws - man:
                    try:
                        os.remove(os.path.join(WS, rel))
                    except OSError:
                        pass
        except Exception as e:
            print("remote apply:", e, flush=True)

    def stop(self):
        """Останавливаем сразу: бот свободен мгновенно, а машине GitHub стоп уходит фоном."""
        if self.stopped:
            return
        self.stopped = True
        self.returncode = -15
        self.done.set()
        self.q.put(None)

        def bg():
            for _ in range(3):
                try:
                    requests.post(f"{self.url}/relay/{self.job}/stop", headers=self.hdr, timeout=20)
                    return
                except Exception:
                    time.sleep(3)
        threading.Thread(target=bg, daemon=True).start()


def oom_first():
    """В дочернем процессе: при нехватке памяти ядро убьёт его, а не бота (повышать можно без root)."""
    try:
        with open("/proc/self/oom_score_adj", "w") as f:
            f.write("1000")
    except Exception:
        pass


CPU_LIMIT = float(os.environ.get("CLAUDE_CPU", "0.2"))  # доля ядра для Claude и его команд
_CLK = os.sysconf("SC_CLK_TCK")


def group_cpu(pgid):
    """Суммарное CPU-время (с) всех процессов группы, включая завершившихся детей."""
    tot = 0
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        try:
            with open(f"/proc/{d}/stat") as f:
                st = f.read().rsplit(")", 1)[1].split()
        except Exception:
            continue
        if int(st[2]) == pgid:  # pgrp
            tot += int(st[11]) + int(st[12]) + int(st[13]) + int(st[14])
    return tot / _CLK


def cpu_throttle(proc, run):
    """Wispbyte гасит сервер за высокую нагрузку на CPU. Пока Claude работает, держим его группу
    процессов в пределах CPU_LIMIT: если превысил — ненадолго замораживаем (SIGSTOP/SIGCONT)."""
    if CPU_LIMIT <= 0 or isinstance(proc, RemoteProc):
        return
    last_t, last_c = time.time(), group_cpu(proc.pid)
    while proc.poll() is None and not run.get("stopped"):
        time.sleep(0.5)
        now, c = time.time(), group_cpu(proc.pid)
        used, dt = c - last_c, now - last_t
        pause = used / CPU_LIMIT - dt
        if pause > 0.05:
            try:
                os.killpg(proc.pid, 19)  # SIGSTOP
                time.sleep(min(pause, 3))
            finally:
                try:
                    os.killpg(proc.pid, 18)  # SIGCONT
                except Exception:
                    pass
        last_t, last_c = time.time(), group_cpu(proc.pid)


def kill_run(proc):
    """Остановить Claude и всё, что он запустил (вся группа процессов)."""
    if proc is None:  # быстрый режим останавливается по флагу stopped
        return
    if isinstance(proc, RemoteProc):
        return proc.stop()
    try:
        os.killpg(proc.pid, 15)
        os.killpg(proc.pid, 18)  # разморозить, если стоял на паузе ограничителя CPU
    except Exception:
        try:
            proc.terminate()
        except Exception:
            pass


def safe_tail(text, n=3500):
    """Хвост текста для черновика без «рваной» разметки: с границы абзаца, с закрытым ```."""
    if len(text) > n:
        cut = text.find("\n\n", len(text) - n)
        text = "…\n\n" + text[cut + 2 if cut != -1 else len(text) - n:]
    if text.count("```") % 2:
        text += "\n```"
    text = re.sub(r"<details[^>]*>(?![\s\S]*</details>)", "", text)
    return text


def md_esc(t):
    return re.sub(r"([\\`*_\[\]<>|~=#$])", r"\\\1", t)


def details(title, body):
    return f"<details><summary>{html.escape(title)}</summary>\n\n{body}\n\n</details>"


def send_rich(chat_id, body):
    """HTML-текст (меню, справка): переводы строк -> <br>, т.к. rich HTML их схлопывает."""
    r = tg("sendRichMessage", chat_id=chat_id, rich_message={"html": body.replace("\n", "<br>")})
    if not r.get("ok"):  # запасной путь для старых клиентов
        r = tg("sendMessage", chat_id=chat_id, text=body, parse_mode="HTML")
        if not r.get("ok"):
            tg("sendMessage", chat_id=chat_id, text=re.sub(r"<[^>]+>", "", body)[:4000])


# ---------------- меню ----------------
def kb(rows):
    return {"inline_keyboard": [[{"text": t, "callback_data": d} for t, d in row] for row in rows]}


def menu_main():
    p, m = cfg["provider"], cfg["model"]
    return (f"🤖 <b>Claude Code</b>\nПровайдер: <code>{html.escape(p)}</code>\nМодель: <code>{html.escape(m)}</code>"
            f"\nEffort: <code>{cfg.get('effort') or 'по умолчанию'}</code>\nРежим: {MODES.get(cfg['mode'], cfg['mode'])}"
            f"\nECC: {len(ecc_cmds)} команд, навыки {'вкл' if cfg.get('ecc_skills') else 'выкл'}",
            kb([[("🧠 Модель", "models"), ("🔌 Провайдеры", "provs")],
                [("⚡ Effort", "effort"), ("🛡 Режим", "mode")],
                [("🆕 Новая сессия", "new"), ("📜 Сессии", "sess")],
                [("👥 Группы и каналы", "chats"), ("🧩 ECC", "ecc")],
                [("🎨 Генерация фото/видео", "gen"), ("📁 Синхронизировать", "sync")]]))


def menu_effort():
    cur = cfg.get("effort") or ""
    rows = [[(("✅ " if e == cur else "") + e, "e:" + e) for e in EFFORTS[:3]],
            [(("✅ " if e == cur else "") + e, "e:" + e) for e in EFFORTS[3:]] + [(("✅ " if not cur else "") + "авто", "e:")],
            [("⬅️ Назад", "main")]]
    return "Effort — сколько модель думает. У сторонних провайдеров может не поддерживаться.", kb(rows)


def menu_mode():
    rows = [[(("✅ " if k == cfg["mode"] else "") + v, "mo:" + k)] for k, v in MODES.items()]
    return "Режим разрешений:", kb(rows + [[("⬅️ Назад", "main")]])


def session_title(chat):
    ch = C(chat)
    if ch.get("temp"):
        return "🕶 временная (не сохранится)"
    for h in ch["history"]:
        if h["id"] == ch["session"]:
            return h["title"] or "…"
    return "новая" if not ch["session"] else ch["session"][:8]


def switch_session(chat, sid, temp=False):
    """Переключить сессию чата: история быстрого режима своя у каждой сессии, временная удаляется при выходе."""
    ch = C(chat)
    old = ch["session"]
    if ch.get("temp_sid") and ch["temp_sid"] != sid:  # уходим из временной — стираем её
        for f in session_file(ch["temp_sid"]):
            try:
                os.remove(f)
            except OSError:
                pass
        fast.clear_hist(HERE, chat)
        old = None
    ch.pop("temp_sid", None)
    if old and old != sid:
        fast.stash_hist(HERE, chat, old)
    else:
        fast.clear_hist(HERE, chat)
    if sid:
        fast.unstash_hist(HERE, chat, sid)
    ch["session"], ch["temp"] = sid, bool(temp)
    save_cfg()


def menu_sessions(chat):
    ch, rows = C(chat), []
    for h in ch["history"][:30]:
        mark = "✅ " if h["id"] == ch["session"] else ""
        when = time.strftime("%d.%m %H:%M", time.localtime(h["ts"]))
        rows.append([(f"{mark}{when} · {h['title'] or '…'}"[:60], "r:" + h["id"]), ("✏️", "sn:" + h["id"]),
                     ("🗑", "rd:" + h["id"])])
    text = (f"Сейчас: <b>{html.escape(session_title(chat))}</b>\n"
            + ("Нажми сессию, чтобы переключиться (агент и быстрый режим её помнят), ✏️ — переименовать, 🗑 — удалить."
               if rows else "Сохранённых сессий пока нет."))
    return text, kb(rows + [[("🆕 Новая", "new"), ("🕶 Временная", "tmp")],
                            [("🧹 Очистить чат и удалить текущую", "clear")], [("⬅️ Назад", "main")]])


def menu_chats():
    rows = []
    for cid, ch in cfg.get("chats", {}).items():
        if ch.get("type") in ("group", "supergroup", "channel"):
            icon = "📢" if ch["type"] == "channel" else "👥"
            rows.append([(f"{icon} {ch.get('title') or cid}", "ch:" + cid)])
    text = ("Чаты, где я есть. Добавь меня в группу или канал — он появится тут." if not rows
            else "Группы и каналы — нажми, чтобы настроить:")
    return text, kb(rows + [[("⬅️ Назад", "main")]])


def menu_chat(cid):
    ch = C(cid)
    acc = {"owner": "👤 только ты", "all": "👥 все"}[ch["access"]]
    rep_ = {"mention": "🔔 по @упоминанию/ответу", "all": "💬 на все сообщения"}[ch["reply"]]
    pr = chat_prompt(cid)
    text = (f"<b>{html.escape(ch.get('title') or cid)}</b>\nКто может писать: {acc}\nКогда отвечаю: {rep_}\n"
            f"Доступ к серверу и файлам: {'✅ да' if ch['trust'] else '❌ нет (только чат)'}\n"
            f"Инструкции: {html.escape(pr[:300]) if pr else '— (задать: /prompt в том чате или скажи мне там)'}")
    return text, kb([[("Кто пишет: " + acc, "ca:" + cid)], [("Когда: " + rep_, "cr:" + cid)],
                     [("Сервер: " + ("✅" if ch["trust"] else "❌"), "ct:" + cid)],
                     [("🧹 Сбросить инструкции", "cp:" + cid), ("🆕 Новая сессия", "cn:" + cid)],
                     [("⬅️ Назад", "chats")]])


def menu_ecc():
    sk = "✅ вкл" if cfg.get("ecc_skills") else "❌ выкл"
    return (f"🧩 <b>Everything Claude Code</b>\nКоманд: {len(ecc_cmds)}. Список — /ecc.\n"
            "Навыки (311 шт.) добавляют контекст к каждому запросу; на слабой модели можно выключить.",
            kb([[("Навыки: " + sk, "ecc_sk")], [("🔄 Обновить ECC", "ecc_up")], [("⬅️ Назад", "main")]]))


PAGE = 24


def menu_models(page=None):
    p = cfg["providers"][cfg["provider"]]
    ms = p["models"]
    if page is None:
        page = ms.index(cfg["model"]) // PAGE if cfg["model"] in ms else 0
    pages = max(1, (len(ms) + PAGE - 1) // PAGE)
    page = min(max(page, 0), pages - 1)
    btn = [(("✅ " if m == cfg["model"] else "") + m.split("/")[-1][:30], f"mi:{i}")
           for i, m in enumerate(ms) if page * PAGE <= i < (page + 1) * PAGE]
    rows = [btn[i:i + 2] for i in range(0, len(btn), 2)]
    if pages > 1:
        rows.append([("◀️", f"mp:{page - 1}"), (f"{page + 1}/{pages}", "noop"), ("▶️", f"mp:{page + 1}")])
    note = ("\n\n🔒 Ключ не даёт доступа (скрыты): " + ", ".join(p["hidden"])) if p.get("hidden") else ""
    return f"Выбери модель ({len(ms)}):" + note, kb(rows + [[("⬅️ Назад", "main")]])


def mask(tok):
    return ("…" + tok[-4:]) if tok and len(tok) > 8 else ("задан" if tok else "нет")


def fetch_models(p):
    """GET {base}/v1/models → (текстовые, {"image": [...], "audio": [...], "video": [...]})."""
    h = {"Authorization": "Bearer " + p["token"]} if p.get("token") else {}
    j = requests.get(p["base_url"].rstrip("/") + "/v1/models", headers=h, timeout=30).json()
    items = j.get("data") if isinstance(j, dict) else j
    text, media = [], {}
    for it in items or []:
        mid = it.get("id") or it.get("name") if isinstance(it, dict) else str(it)
        if not mid or mid.startswith("community/"):
            continue
        cat = (it.get("category") if isinstance(it, dict) else None) or "text"
        out = it.get("output_modalities") if isinstance(it, dict) else None
        if cat == "text" and (not out or "text" in out):
            text.append(mid)
        else:
            media.setdefault(cat, []).append(mid)
    return text, media


def env_providers():
    """PROV_<ИМЯ>=base_url|ключ[|модель1,модель2] в .env → провайдер в меню (ключ обновляется, модели тянутся с сайта)."""
    changed = False
    envs = dict(os.environ)
    for k in list(envs):  # вариант с раздельными полями: PROV_X_URL, PROV_X_KEY, PROV_X_MODELS
        if k.startswith("PROV_") and k.endswith("_URL") and envs.get(k[:-4] + "_KEY"):
            envs[k[:-4]] = "|".join([envs[k], envs[k[:-4] + "_KEY"], envs.get(k[:-4] + "_MODELS", "")])
    for k, v in envs.items():
        if not k.startswith("PROV_") or "|" not in v or k.endswith(("_URL", "_KEY", "_MODELS", "_ACCESS", "_UID")):
            continue
        parts = [x.strip() for x in v.split("|")]
        name = k[5:].lower()
        url = re.sub(r"/v1$", "", parts[0].rstrip("/"))
        token = parts[1] if len(parts) > 1 else ""
        want = [m.strip() for m in (parts[2] if len(parts) > 2 else "").split(",") if m.strip()]
        acc, uid = envs.get(k + "_ACCESS", ""), envs.get(k + "_UID", "")
        p = cfg.setdefault("providers", {}).get(name)
        if p and p.get("base_url") == url and p.get("token") == token and p.get("access", "") == acc \
                and str(p.get("uid", "")) == uid:
            continue
        p = p or {"models": []}
        p.update(base_url=url, token=token, access=acc, uid=uid)
        if want or not p.get("models"):
            ms = want
            if not ms:
                try:
                    ms = fetch_models(p)[0]
                except Exception:
                    ms = []
            p["models"] = ms or ["claude-sonnet-5"]
        cfg["providers"][name] = p
        changed = True
    if changed:
        if cfg.get("provider") not in cfg.get("providers", {}):
            cfg["provider"] = next(iter(cfg["providers"]))
            cfg["model"] = cfg["providers"][cfg["provider"]]["models"][0]
        save_cfg()


def menu_prov(name):
    p = cfg["providers"][name]
    media = p.get("media") or {}
    lines = [f"🔌 <b>{html.escape(name)}</b>" + (" ✅" if name == cfg["provider"] else ""),
             f"Сайт: <code>{html.escape(p.get('base_url') or 'Anthropic по умолчанию')}</code>",
             f"Ключ: {mask(p.get('token'))}",
             f"Моделей: {len(p.get('models', []))}" + (f" (🔒 скрыто {len(p['hidden'])})" if p.get("hidden") else "")]
    for cat, ms in media.items():
        lines.append(f"{ {'image': '🖼', 'audio': '🔊', 'video': '🎬'}.get(cat, '📦')} {cat}: {len(ms)}")
    rows = [[("✅ Выбрать", "p:" + name), ("🔄 Список моделей с сайта", "pf:" + name)],
            [("🔑 Заменить ключ", "pk:" + name), ("🌐 Заменить сайт", "pu:" + name)],
            [("➕ Добавить модели", "pa:" + name), ("➖ Убрать модель", "px:" + name)],
            [("✏️ Переименовать", "pn:" + name)] + ([("🗑 Удалить", "del:" + name)] if name != "anthropic" else []),
            [("⬅️ Назад", "provs")]]
    return "\n".join(lines), kb(rows)


def menu_prov_rm(name, page=0):
    ms = cfg["providers"][name].get("models", [])
    pages = max(1, (len(ms) + PAGE - 1) // PAGE)
    page = min(max(page, 0), pages - 1)
    btn = [("➖ " + m.split("/")[-1][:28], f"pd:{name}:{i}") for i, m in enumerate(ms)
           if page * PAGE <= i < (page + 1) * PAGE]
    rows = [btn[i:i + 2] for i in range(0, len(btn), 2)]
    if pages > 1:
        rows.append([("◀️", f"pxp:{name}:{page - 1}"), (f"{page + 1}/{pages}", "noop"),
                     ("▶️", f"pxp:{name}:{page + 1}")])
    return "Нажми модель, чтобы убрать её из списка:", kb(rows + [[("⬅️ Назад", "pe:" + name)]])


PROV_ASK = {"pk": "Пришли новый API-ключ (сообщение сразу удалю).",
            "pu": "Пришли новый адрес сайта, например <code>https://api.example.com</code> (без /v1).",
            "pa": "Пришли модели через запятую: <code>model-1, model-2</code>",
            "pn": "Пришли новое имя провайдера."}


def prov_input(msg, what, name):
    chat = msg["chat"]["id"]
    text = (msg.get("text") or "").strip()
    p = cfg["providers"].get(name)
    if not p or not text:
        return
    if what == "pk":
        tg("deleteMessage", chat_id=chat, message_id=msg["message_id"])
        p["token"] = text; note = "🔑 Ключ заменён"
    elif what == "pu":
        if not text.startswith("http"):
            return tg("sendMessage", chat_id=chat, text="Адрес должен начинаться с http")
        p["base_url"] = re.sub(r"/v1$", "", text.rstrip("/")); note = "🌐 Сайт заменён"
    elif what == "pa":
        new = [m.strip() for m in text.split(",") if m.strip()]
        p["models"] = list(dict.fromkeys(p.get("models", []) + new)); note = f"➕ Добавлено: {len(new)}"
    elif what == "pn":
        if text in cfg["providers"]:
            return tg("sendMessage", chat_id=chat, text="Такое имя уже есть")
        cfg["providers"] = {(text if k == name else k): v for k, v in cfg["providers"].items()}
        if cfg["provider"] == name:
            cfg["provider"] = text
        name, note = text, "✏️ Переименован"
    save_cfg()
    if what in ("pk", "pu"):
        refresh_models()
    t, m = menu_prov(name)
    tg("sendMessage", chat_id=chat, text=note + "\n\n" + t, parse_mode="HTML", reply_markup=m)


fetched = {}  # провайдер -> (текстовые, медиа), ждём «заменить/дополнить»


def menu_provs():
    rows = []
    for name in cfg["providers"]:
        mark = "✅ " if name == cfg["provider"] else ""
        rows.append([(mark + name, "p:" + name), ("⚙️", "pe:" + name)])
    rows += [[("➕ Добавить", "add"), ("💰 Балансы", "bals")], [("⬅️ Назад", "main")]]
    return "Провайдеры (⚙️ — ключ, сайт, модели):", kb(rows)


ADD_HELP = ("Пришли одной строкой:\n<code>имя | base_url | токен | модель1, модель2</code>\n\n"
            "Пример: <code>myproxy | https://api.example.com | sk-xxx | claude-sonnet-4-5, glm-4.6</code>\n"
            "Сообщение с токеном я сразу удалю.")


def menu_live(chat):
    rows, lines = [], []
    for d, r in list(runs.items()):
        if r["chat"] != chat or r["stopped"]:
            continue
        st = r["st"]
        icon = "⚡" if r["kind"] == "fast" else "🤖"
        tok = f" · 🔤 {fmt_k(st.get('tin', 0) + st.get('tout', 0))}" if r["kind"] == "claude" else ""
        lines.append(f"{icon} «{html.escape(r['title'])}» — {fmt_dur(time.time() - r['started'])} · "
                     f"шагов {len(st['steps'])}{tok}")
        mark = "👁 " if focused(chat, d) and not live[chat].get("agent") else ""
        rows.append([(f"{mark}{icon} {r['title'][:28]}", f"lv:{d}"), ("⏹", f"ls:{d}")])
        for i, (aid, a) in enumerate(list(r["agents"].items())[:12]):
            lines.append(f"    🧩 {html.escape(a['name'])}: {html.escape(a['last'][:60] or 'работает…')}")
            mark = "👁 " if focused(chat, d) and live[chat].get("agent") == aid else ""
            rows.append([(f"   {mark}🧩 {a['name'][:30]}", f"lv:{d}:{i}")])
    if not rows:
        return "Сейчас ничего не выполняется.", None
    rows.append([("🙈 Скрыть трансляцию", "lvoff"), ("🔄", "lvref")])
    return ("📡 <b>Работает сейчас</b>\n" + "\n".join(lines) +
            "\n\nНажми задачу или агента — трансляция покажет его с текущего места.", kb(rows))


def show(chat_id, msg_id, screen):
    text, markup = screen
    tg("editMessageText", chat_id=chat_id, message_id=msg_id, text=text,
       parse_mode="HTML", reply_markup=markup)


def on_callback(q):
    if q["from"]["id"] != OWNER:
        return tg("answerCallbackQuery", callback_query_id=q["id"], text="Нет доступа")
    d, chat, mid = q["data"], q["message"]["chat"]["id"], q["message"]["message_id"]
    note = ""
    if not d.startswith("l"):
        live_off(chat)  # нажал что-то в боте — трансляция прячется, вернуть: /live
    if d.startswith("lv:"):
        parts = d.split(":")
        did = int(parts[1])
        r = runs.get(did)
        if not r:
            note = "Эта задача уже закончилась"
        else:
            aid = None
            if len(parts) > 2:
                keys = list(r["agents"].keys())
                aid = keys[int(parts[2])] if int(parts[2]) < len(keys) else None
            live_on(chat, did, aid)
            r["st"]["dirty"] = True
            note = "📡 Трансляция: " + (r["agents"][aid]["name"] if aid else r["title"])
        t, m = menu_live(chat)
        tg("editMessageText", chat_id=chat, message_id=mid, text=t, parse_mode="HTML", reply_markup=m)
        return tg("answerCallbackQuery", callback_query_id=q["id"], text=note)
    if d.startswith("ls:"):
        r = runs.get(int(d[3:]))
        if r:
            r["stopped"] = True
            kill_run(r["proc"])
        t, m = menu_live(chat)
        tg("editMessageText", chat_id=chat, message_id=mid, text=t, parse_mode="HTML", reply_markup=m)
        return tg("answerCallbackQuery", callback_query_id=q["id"], text="⏹ Остановлено" if r else "Уже закончилась")
    if d in ("lvoff", "lvref"):
        if d == "lvoff":
            live_off(chat)
        t, m = menu_live(chat)
        tg("editMessageText", chat_id=chat, message_id=mid, text=t, parse_mode="HTML", reply_markup=m)
        return tg("answerCallbackQuery", callback_query_id=q["id"], text="🙈 Скрыто" if d == "lvoff" else "")
    if d == "main":
        show(chat, mid, menu_main())
    elif d == "models":
        show(chat, mid, menu_models())
    elif d == "provs":
        show(chat, mid, menu_provs())
    elif d == "bals":
        tg("answerCallbackQuery", callback_query_id=q["id"], text="Проверяю балансы…")
        show(chat, mid, (balances_text(), kb([[("🔄 Обновить", "bals"), ("⬅️ Назад", "provs")]])))
        return
    elif d.startswith("m:") or d.startswith("mi:"):
        ms = cfg["providers"][cfg["provider"]]["models"]
        m = d[2:] if d.startswith("m:") else (ms[int(d[3:])] if int(d[3:]) < len(ms) else cfg["model"])
        cfg["model"] = m; save_cfg(); note = "Модель: " + m
        show(chat, mid, menu_main())
    elif d.startswith("mp:"):
        show(chat, mid, menu_models(int(d[3:])))
    elif d == "noop":
        pass
    elif d.startswith("pe:") and d[3:] in cfg["providers"]:
        show(chat, mid, menu_prov(d[3:]))
    elif d[:3] in ("pk:", "pu:", "pa:", "pn:") and d[3:] in cfg["providers"]:
        waiting[OWNER] = (d[:2], d[3:])
        tg("sendMessage", chat_id=chat, text=PROV_ASK[d[:2]], parse_mode="HTML")
    elif d.startswith("px:") and d[3:] in cfg["providers"]:
        show(chat, mid, menu_prov_rm(d[3:]))
    elif d.startswith("pxp:"):
        name, pg = d[4:].rsplit(":", 1)
        if name in cfg["providers"]:
            show(chat, mid, menu_prov_rm(name, int(pg)))
    elif d.startswith("pd:"):
        name, i = d[3:].rsplit(":", 1)
        p = cfg["providers"].get(name)
        if p and int(i) < len(p["models"]) and len(p["models"]) > 1:
            gone = p["models"].pop(int(i)); note = "Убрана: " + gone
            if name == cfg["provider"] and cfg["model"] == gone:
                cfg["model"] = p["models"][0]
            save_cfg()
            show(chat, mid, menu_prov_rm(name, int(i) // PAGE))
        else:
            note = "Последнюю модель убрать нельзя"
    elif d.startswith("pf:") and d[3:] in cfg["providers"]:
        name, p = d[3:], cfg["providers"][d[3:]]
        try:
            text_ms, media = fetch_models(p)
        except Exception as e:
            text_ms, media = [], {}
            note = "Не получилось: " + str(e)[:150]
        if text_ms or media:
            ok = allowed_models(p)
            if ok is not None:
                text_ms = [m for m in text_ms if m in ok]
            fetched[name] = (text_ms, media)
            new = [m for m in text_ms if m not in p.get("models", [])]
            mtxt = "".join(f"\n{k}: {len(v)}" for k, v in media.items())
            tg("editMessageText", chat_id=chat, message_id=mid, parse_mode="HTML",
               text=f"🔄 На сайте {len(text_ms)} текстовых моделей, новых: {len(new)}.{mtxt}\n\n"
                    "Заменить список целиком или только дополнить новыми?",
               reply_markup=kb([[("♻️ Заменить", "pfr:" + name), ("➕ Дополнить", "pfa:" + name)],
                                [("⬅️ Назад", "pe:" + name)]]))
        elif not note:
            note = "Сайт не отдал список моделей"
    elif d[:4] in ("pfr:", "pfa:") and d[4:] in fetched and d[4:] in cfg["providers"]:
        name, p = d[4:], cfg["providers"][d[4:]]
        text_ms, media = fetched.pop(name)
        if text_ms:
            p["models"] = text_ms if d.startswith("pfr") else list(dict.fromkeys(p.get("models", []) + text_ms))
        p["media"] = media
        if name == cfg["provider"] and cfg["model"] not in p["models"]:
            cfg["model"] = p["models"][0]
        save_cfg(); note = f"Моделей теперь: {len(p['models'])}"
        show(chat, mid, menu_prov(name))
    elif d.startswith("p:") and d[2:] in cfg["providers"]:
        cfg["provider"] = d[2:]
        cfg["model"] = cfg["providers"][d[2:]]["models"][0]
        for c in cfg.get("chats", {}).values():
            c["session"] = None  # сессии разных провайдеров несовместимы
        save_cfg(); note = "Провайдер: " + d[2:]
        show(chat, mid, menu_main())
    elif d.startswith("del:"):
        cfg["providers"].pop(d[4:], None)
        if cfg["provider"] not in cfg["providers"]:
            cfg.update(provider="anthropic", model="sonnet")
        save_cfg(); note = "Удалён"
        show(chat, mid, menu_provs())
    elif d == "add":
        waiting[OWNER] = "add_provider"
        tg("sendMessage", chat_id=chat, text=ADD_HELP, parse_mode="HTML")
    elif d == "new":
        switch_session(chat, None); note = "Новая сессия"
        show(chat, mid, menu_sessions(chat))
    elif d == "tmp":
        switch_session(chat, None, temp=True); note = "Временная сессия: не сохранится"
        show(chat, mid, menu_sessions(chat))
    elif d.startswith("sn:"):
        waiting[OWNER] = ("rename_sess", d[3:])
        tg("sendMessage", chat_id=chat, text="✏️ Напиши новое название сессии:")
    elif d == "clear":
        n = clear_chat(chat); note = f"Удалено сообщений: {n}"
        return tg("answerCallbackQuery", callback_query_id=q["id"], text=note)
    elif d.startswith("rd:"):
        delete_session(chat, d[3:]); note = "Сессия удалена"
        show(chat, mid, menu_sessions(chat))
    elif d == "chats":
        show(chat, mid, menu_chats())
    elif d[:3] in ("ch:", "ca:", "cr:", "ct:", "cp:", "cn:"):
        cid, ch = d[3:], C(d[3:])
        if d.startswith("ca:"):
            ch["access"] = "all" if ch["access"] == "owner" else "owner"
        elif d.startswith("cr:"):
            ch["reply"] = "all" if ch["reply"] == "mention" else "mention"
        elif d.startswith("ct:"):
            ch["trust"] = not ch["trust"]
        elif d.startswith("cp:"):
            chat_prompt(cid, "")
        elif d.startswith("cn:"):
            ch["session"] = None
        save_cfg()
        show(chat, mid, menu_chat(cid))
    elif d == "effort":
        show(chat, mid, menu_effort())
    elif d.startswith("e:"):
        cfg["effort"] = d[2:]; save_cfg(); note = "Effort: " + (d[2:] or "авто")
        show(chat, mid, menu_main())
    elif d == "mode":
        show(chat, mid, menu_mode())
    elif d.startswith("mo:") and d[3:] in MODES:
        cfg["mode"] = d[3:]; save_cfg(); note = MODES[d[3:]]
        show(chat, mid, menu_main())
    elif d == "sess":
        show(chat, mid, menu_sessions(chat))
    elif d.startswith("r:"):
        switch_session(chat, d[2:]); note = "Продолжаю эту сессию"
        show(chat, mid, menu_sessions(chat))
    elif d == "gen":
        show(chat, mid, menu_gen())
    elif d.startswith("gmo:"):
        gen_cfg()["mode"] = d[4:]; save_cfg(); note = GEN_MODES.get(d[4:], "")
        show(chat, mid, menu_gen())
    elif d in ("gim", "gvm"):
        show(chat, mid, menu_gen_models("image" if d == "gim" else "video"))
    elif d.startswith(("gi:", "gv:")):
        kind = "image" if d.startswith("gi:") else "video"
        lst = GEN_IMAGE if kind == "image" else GEN_VIDEO
        i = int(d[3:])
        if i < len(lst):
            gen_cfg()[kind] = lst[i][0]; save_cfg(); note = "Модель: " + lst[i][1]
        show(chat, mid, menu_gen())
    elif d == "ecc":
        show(chat, mid, menu_ecc())
    elif d == "ecc_sk":
        cfg["ecc_skills"] = not cfg.get("ecc_skills"); save_cfg(); link_ecc()
        show(chat, mid, menu_ecc())
    elif d == "ecc_up":
        tg("answerCallbackQuery", callback_query_id=q["id"], text="Обновляю ECC…")
        threading.Thread(target=lambda: (install_ecc(force=True), register_commands(),
                                         tg("sendMessage", chat_id=chat, text=f"🧩 ECC обновлён: {len(ecc_cmds)} команд")),
                         daemon=True).start()
        return
    elif d == "sync":
        with fs_lock:
            a, r = fs.sync()
        note = f"Синхронизировано: +{a} −{r}"
    tg("answerCallbackQuery", callback_query_id=q["id"], text=note)


def add_provider(msg):
    tg("deleteMessage", chat_id=msg["chat"]["id"], message_id=msg["message_id"])
    parts = [x.strip() for x in msg["text"].split("|")]
    if len(parts) != 4 or not parts[0] or not parts[1].startswith("http"):
        return tg("sendMessage", chat_id=msg["chat"]["id"], text="Не понял формат.\n\n" + ADD_HELP, parse_mode="HTML")
    name, url, token, models = parts
    models = [m.strip() for m in models.split(",") if m.strip()] or ["sonnet"]
    url = re.sub(r"/v1$", "", url.rstrip("/"))  # Claude Code сам добавляет /v1/messages
    cfg["providers"][name] = {"base_url": url, "token": token, "models": models}
    save_cfg()
    refresh_models()
    text, markup = menu_provs()
    tg("sendMessage", chat_id=msg["chat"]["id"], text=f"✅ Добавлен {html.escape(name)}\n\n" + text,
       parse_mode="HTML", reply_markup=markup)


HELP = """<b>Как пользоваться</b>
Пиши задачу текстом — Claude Code выполнит её в папке проекта.
📎 Можно прислать фото, скриншот или файл (до 20 МБ) с подписью-задачей — он посмотрит.

<b>Команды</b>
/menu — модель, провайдеры, effort, режим, ECC
/gen — генерация: модели фото и видео, режим «каждое сообщение — фото/видео» · /image промпт · /video промпт
/new — новая сессия · /temp — временная (не сохранится) · /resume — сессии: переключить, ✏️ переименовать, 🗑 удалить
/clear — очистить чат и удалить текущую сессию
✍️ Пока агент работает, просто пиши — уточнение уйдёт ему прямо во время работы (или /to текст). Новая отдельная задача: /task текст
🎨 Попроси картинку или видео — модель сама напишет промпт и сгенерирует (GPT Image 2.5, Nano Banana, FLUX, LTX/Wan; без цензуры — AI Horde)
🌐 Попроси что-то сделать в браузере — агент откроет настоящий Chromium и пришлёт ссылку, чтобы смотреть вживую
/effort high — уровень размышлений · /model имя — модель
/plan — режим плана · /mode — режим разрешений
/compact /context /init /review /security_review — команды Claude Code
/stop — остановить · /live — трансляция задач и агентов · /status — состояние · /files — файлы
/usage — кредиты и остаток · /agents — чаты агентов · /skills — навыки · /repair — починить канал
/chats — группы и каналы · /prompt текст — инструкции для чата
📊 Внизу ответа: время • ходы • токены • 💰 списано • 💳 остаток
/ecc — все команды Everything Claude Code (например /code_review, /plan_prd, /tdd)
Любую команду ECC можно писать и через дефис: /code-review"""


def fast_ok(prompt):
    """Быстрый режим: обычные сообщения. Команды Claude Code и присланные файлы — сразу в Claude Code."""
    return cfg.get("speed", "auto") == "auto" and not prompt.startswith("/") and "Приложены файлы" not in prompt


def fast_system(chat, guest, who, mid):
    ch = C(chat)
    where = "личный чат с владельцем" if int(chat) > 0 else f"{ch['type']} «{ch['title']}»"
    h = [f"Ты — Telegram-бот @{BOT_USERNAME}, быстрый режим. Чат: {where}. Пишет: {who}. "
         "Отвечай сразу, кратко и по делу, по-русски, если пользователь не пишет на другом языке. "
         "Ответ уходит rich-сообщением в Markdown (GFM): заголовки, таблицы, код, формулы $x^2$, ||спойлер||.",
         "Для фактов из интернета используй web_fetch (поиск: https://html.duckduckgo.com/html/?q=...)."]
    if not guest:
        h.append("bash выполняет команды на сервере Render (Linux, есть интернет) — для быстрых проверок и расчётов. "
                 "Если просят написать, создать или изменить код, файлы, сайт, проект, если задача большая, "
                 "многошаговая или нужна сборка — НЕ делай сам, сразу вызови claude_code с полной задачей.")
        h.append("Можешь писать длинные красивые ответы-статьи: заголовки, таблицы, списки, цитаты, формулы. "
                 "Графики и диаграммы строй инструментом chart.")
        h.append(POLL_HINT)
        rs = runs_summary(chat)
        if rs:
            h.append("Сейчас параллельно работает агент Claude Code (пользователь может спрашивать о нём, отвечай по этим "
                     "данным; чтобы смотреть вживую — команда /live). Если пользователь уточняет, поправляет или дополняет "
                     "задачу агента — вызови tell_agent с этим текстом и коротко подтверди. Новую отдельную задачу — "
                     "claude_code:\n" + rs)
    p = chat_prompt(chat)
    if p:
        h.append("Инструкции владельца для этого чата: " + p)
    return "\n".join(h)


MEDIA_TOOLS = [
    {"name": "generate_image", "guest": True,
     "description": "Сгенерировать картинку. Пиши подробный промпт на английском (сюжет, стиль, свет, ракурс). "
     "model оставляй пустым — возьмётся модель, выбранная владельцем в /gen; указывай, только если просят конкретную: "
     "gpt-image-2.5-flare (GPT Image 2.5), gemini-nano-banana-2.1 (Nano Banana), gemini-3-pro-image, flux. nsfw=true — без цензуры (медленно, очередь). Картинка прикрепится к ответу.",
     "input_schema": {"type": "object", "properties": {"prompt": {"type": "string"}, "model": {"type": "string"},
                                                       "nsfw": {"type": "boolean"}, "size": {"type": "string",
                                                       "description": "например 1024x1024, 1024x1536, 1536x1024"}},
                      "required": ["prompt"]}},
    {"name": "generate_video", "description": "Сгенерировать короткое видео (2–5 с). Подробный промпт на английском: "
     "сюжет, движение, камера. image — путь или URL картинки, чтобы оживить её. Видео прикрепится к ответу.",
     "input_schema": {"type": "object", "properties": {"prompt": {"type": "string"}, "image": {"type": "string"},
                                                       "seconds": {"type": "number"}}, "required": ["prompt"]}},
    {"name": "browser", "description": "Настоящий Chromium в облаке (владелец получает ссылку и смотрит вживую). "
     "cmd — одна команда: 'open URL', 'goto URL', 'read' (текст и пронумерованные элементы), 'click N', "
     "'type N текст --enter', 'key Enter', 'scroll', 'shot' (скриншот приложится), 'eval JS', 'close'. "
     "Для JS-сайтов, входа в аккаунты, форм и кликов; простые страницы читай web_fetch.",
     "input_schema": {"type": "object", "properties": {"cmd": {"type": "string"}}, "required": ["cmd"]}},
]


def media_tools(guest):
    out = []
    for t in MEDIA_TOOLS:
        if t["name"] == "browser" and (guest or not os.environ.get("STEEL_API_KEY")):
            continue
        if guest and not t.get("guest"):
            continue
        out.append({k: v for k, v in t.items() if k != "guest"})
    return out


def media_handlers(chat, guest):
    import media, browser

    def img(inp):
        try:
            g = gen_cfg()
            os.environ["MEDIA_IMAGE"], os.environ["MEDIA_VIDEO"] = g["image"], g["video"]
            p = media.image(inp.get("prompt", ""), model=inp.get("model") or None, nsfw=bool(inp.get("nsfw")) and not guest,
                            size=inp.get("size") or "1024x1024")
            return "🎨 " + inp.get("prompt", "")[:70], "Готово, картинка приложится к ответу. Ссылку не вставляй.", \
                ("file:" + p, inp.get("prompt", "")[:200])
        except Exception as e:
            return "🎨 ошибка генерации", f"ошибка: {e}", None

    def vid(inp):
        try:
            g = gen_cfg()
            os.environ["MEDIA_IMAGE"], os.environ["MEDIA_VIDEO"] = g["image"], g["video"]
            p = media.video(inp.get("prompt", ""), inp.get("image") or None, seconds=inp.get("seconds") or 3)
            return "🎬 " + inp.get("prompt", "")[:70], "Готово, видео приложится к ответу.", ("file:" + p, "")
        except Exception as e:
            return "🎬 ошибка генерации", f"ошибка: {e}", None

    def brw(inp):
        os.environ["TG_CHAT"] = str(chat)
        cmd = inp.get("cmd", "").strip()
        try:
            import shlex
            out = browser.run(shlex.split(cmd))
        except SystemExit as e:
            out = f"ошибка: {e}"
        except Exception as e:
            out = f"ошибка: {e}"
        if cmd.startswith("shot") and isinstance(out, str) and os.path.exists(out):
            return "🌐 скриншот", "Скриншот приложится к ответу.", ("file:" + out, "")
        return "🌐 " + cmd[:70], str(out)[:15000], None

    h = {"generate_image": img}
    if not guest:
        h.update(generate_video=vid, browser=brw)
    return h


FAST_FALLBACK = ["kimi-k2.7-code", "glm-5.3", "glm-5.3-flash", "grok-4.7", "deepseek-v4.1-flash"]


def run_fast(chat_id, prompt, guest=False, who="владелец", mid=None):
    did = next(draft_ids)
    started = time.time()
    private = int(chat_id) > 0
    st = {"text": "", "steps": [], "dirty": True, "done": False, "thinking": ""}
    runs[did] = {"proc": None, "stopped": False, "chat": chat_id, "kind": "fast", "title": prompt[:40],
                 "started": started, "st": st, "agents": {}, "inbox": []}
    if private:
        live_on(chat_id, did)
    p = cfg["providers"][cfg["provider"]]
    model = cfg.get("fast_model") or cfg["model"]

    def drafter():
        last = 0
        while not st["done"] and not runs[did]["stopped"]:
            if not private:
                tg("sendChatAction", chat_id=chat_id, action="typing"); time.sleep(4); continue
            if not focused(chat_id, did):
                time.sleep(0.3); continue
            if (st["dirty"] and time.time() - last > 1.0) or time.time() - last > 3:
                st["dirty"], last = False, time.time()
                lines = [f"⚡ {spin(did)} · {fmt_dur(time.time() - started)}"] + st["steps"][-3:]
                if st["thinking"] and not st["text"]:
                    lines.append(st["thinking"][-300:])
                head = "<br>".join(html.escape(x) for x in lines)
                tg("sendRichMessageDraft", chat_id=chat_id, draft_id=did, can_stop=True,
                   rich_message={"markdown": f"<tg-thinking>{head}</tg-thinking>\n\n" + safe_tail(st["text"])})
            time.sleep(0.3)

    ui = {"text": lambda d: (st.__setitem__("text", st["text"] + d), st.__setitem__("dirty", True)),
          "step": lambda l: (st["steps"].append(l), st.__setitem__("dirty", True)),
          "new_text": lambda: st.__setitem__("text", ""),
          "think": lambda d: (st.__setitem__("thinking", st["thinking"] + d), st.__setitem__("dirty", True)),
          "inbox": lambda: [runs[did]["inbox"].pop(0) for _ in range(len(runs[did]["inbox"]))],
          "extra_tools": media_tools(guest), "handlers": media_handlers(chat_id, guest)}
    if not guest and active_claude(chat_id):
        def tell(t):
            name = inject(chat_id, t)
            return f"Передано агенту (задача «{name}»)." if name else "Агент уже закончил — уточнение не передано."
        ui["tell_agent"] = tell
    threading.Thread(target=drafter, daemon=True).start()
    # Если модель у провайдера сейчас недоступна (403/429/5xx, кончился баланс), пробуем следующую
    spare = p.get("models", []) + (FAST_FALLBACK if "reformboss" in (p.get("base_url") or "") else [])
    chain = [model] + [m for m in dict.fromkeys(spare) if m != model and m in FAST_FALLBACK
                     and m not in p.get("hidden", [])]
    errors = []
    for model in chain:
        try:
            res = fast.answer(HERE, chat_id, prompt, p.get("base_url"), p.get("token", ""), model,
                              fast_system(chat_id, guest, who, mid), os.environ.get("REXEC_URL", ""),
                              os.environ.get("REXEC_TOKEN", ""), ui, lambda: runs[did]["stopped"], guest)
            break
        except Exception as e:
            import traceback; traceback.print_exc()
            errors.append(f"{model}: {str(e)[:200]}")
            res = {"text": "", "error": str(e), "delegate": None, "steps": [], "in": 0, "out": 0}
            if st["text"] or runs[did]["stopped"] or "провайдер:" not in str(e):
                break
    st["done"] = True
    _r = runs.pop(did)
    stopped, leftover = _r["stopped"], _r.get("inbox") or []
    if focused(chat_id, did):
        live_off(chat_id)
    if res.get("error") and not stopped:  # не молча в Claude Code, а честно показываем ошибку
        res["text"] = "⚠️ Быстрый режим не ответил:\n```\n" + "\n".join(errors)[-1500:] + \
            "\n```\nСмени модель: /fast model ИМЯ"
    if res["delegate"] and not stopped:
        return run_claude(chat_id, res["delegate"] if res["delegate"] != prompt else prompt, guest, who, mid)
    sec = round(time.time() - started, 1)
    text, found = extract_polls(res["text"])
    body = "⏹ Остановлено." if stopped and not text else (text or ("❓ Выбери вариант в опросе." if found else "(пустой ответ)"))
    blocks = details(f"⚙️ Шаги · {len(res['steps'])}", "\n".join(f"{i + 1}. {md_esc(x)}" for i, x in
                                                          enumerate(res["steps"]))) + "\n\n" if res["steps"] else ""
    if st["thinking"].strip():
        th = st["thinking"].strip()[-3000:]
        blocks = details("💭 Размышления", "\n".join("> " + md_esc(l) for l in th.splitlines() if l.strip())) + \
            "\n\n" + blocks
    ag = active_claude(chat_id)
    extra = f"  •  📡 агент работает {fmt_dur(time.time() - ag[0][1]['started'])} — /live" if ag else ""
    footer = f"<footer>⚡ {fmt_dur(sec)}  •  🔤 {fmt_k(res['in'])} → {fmt_k(res['out'])}  •  {html.escape(model)}{extra}</footer>"
    tgctl.rich_send(chat_id, blocks + body + "\n\n" + footer, WS, reply_to=None if private else mid)
    files = [(u[5:], c) for u, c in res.get("images", []) if u.startswith("file:")]
    if files:  # сгенерированные картинки и видео — отдельным сообщением с медиа
        tgctl.rich_send(chat_id, "\n\n".join(f"![{md_esc((c or '')[:80])}](file:{p})" for p, c in files), WS,
                        reply_to=None if private else mid)
    for url, cap in res.get("images", []):
        if url.startswith("file:"):
            continue
        tg("sendPhoto", chat_id=chat_id, photo=url, caption=(cap or "")[:1000])
    send_polls(chat_id, found, "fast")
    if leftover and not stopped:  # дописали, когда ответ уже заканчивался — отвечаем следом
        threading.Thread(target=run_fast, args=(chat_id, "\n\n".join(leftover), guest, who, mid), daemon=True).start()


def start_task(chat, prompt, guest=False, who="владелец", mid=None, force_claude=False):
    if not CHANNEL:
        return tg("sendMessage", chat_id=chat, text="Сначала добавь меня админом в канал для файлов.")
    ch = C(chat)
    if ch.pop("await_claude", None):  # ответ на вопрос агента — продолжает его сессию
        force_claude = True
        save_cfg()
    gmode = gen_cfg()["mode"]
    if not guest and not force_claude and gmode in ("image", "video") and not prompt.startswith("/") \
            and "Приложены файлы" not in prompt:  # режим генерации: каждое сообщение — промпт
        return threading.Thread(target=run_gen, args=(chat, gmode, prompt, mid), daemon=True).start()
    if not guest and not prompt.startswith("/"):
        fr = [r for r in runs.values() if r.get("kind") == "fast" and r["chat"] == chat and not r["stopped"]
              and "inbox" in r and not r["st"].get("done")]
        if fr and not force_claude:  # быстрый режим ещё отвечает — дописанное уйдёт ему же
            fr[-1]["inbox"].append(prompt)
            return
        if not force_claude and not fast_ok(prompt) and active_claude(chat) and "Приложены файлы" not in prompt:
            t = inject(chat, prompt)  # быстрый режим выключен — сразу уточнение агенту
            if t:
                return tg("sendMessage", chat_id=chat, text=f"📨 Передал агенту («{t}»). Отдельная задача: /task текст")
    if not force_claude and fast_ok(prompt):  # быстрые ответы работают всегда, даже пока идёт агент
        return threading.Thread(target=run_fast, args=(chat, prompt, guest, who, mid), daemon=True).start()
    if not remote_on() and active_claude():  # локально два Claude на 512 МБ не поместятся
        return tg("sendMessage", chat_id=chat, text="Ещё работаю над прошлой задачей — подожди или /stop.",
                  **({"reply_parameters": {"message_id": mid, "allow_sending_without_reply": True}} if mid else {}))
    threading.Thread(target=run_claude, args=(chat, prompt, guest, who, mid), daemon=True).start()


def send_long(chat, text, **kw):
    for part in chunks(text):
        tg("sendMessage", chat_id=chat, text=part, **kw)


def status_text(chat):
    try:
        ver = subprocess.run([CLAUDE, "--version"], capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception as e:
        ver = f"не найден ({e.__class__.__name__})"
    du = shutil.disk_usage(HERE)
    mem = ""
    try:
        for f in ("/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory/memory.usage_in_bytes"):
            if os.path.exists(f):
                mem = f"{int(open(f).read()) // 2**20} МБ"
                break
    except Exception:
        pass
    s = C(chat)["session"]
    return (f"🤖 Claude Code: <code>{html.escape(ver or '?')}</code>\n"
            f"Провайдер: <code>{html.escape(cfg['provider'])}</code> · модель <code>{html.escape(cfg['model'])}</code>\n"
            f"Effort: {cfg.get('effort') or 'авто'} · режим: {MODES.get(cfg['mode'])}\n"
            f"Сессия: <code>{s[:8] if s else 'новая'}</code> · задача: {'идёт' if runs else 'нет'}\n"
            f"Где работает Claude: {'GitHub Actions' if remote_on() else 'здесь (Wispbyte)'}\n"
            f"ECC: {len(ecc_cmds)} команд, навыки {'вкл' if cfg.get('ecc_skills') else 'выкл'}\n"
            f"Диск: свободно {du.free // 2**20} МБ из {du.total // 2**20} МБ" + (f"\nПамять: {mem}" if mem else ""))


def usage_text():
    lr, stt = cfg.get("last_run"), cfg.get("stats") or {}
    lines = [f"📊 <b>Расход</b> · {html.escape(cfg['provider'])} / <code>{html.escape(cfg['model'])}</code>"]
    b = provider_balance()
    if b:
        lines.append("Баланс провайдера: " + fmt_bal(b))
    if lr:
        c = f"${lr['cost']:.4f}" + ("" if lr.get("real") else " (оценка)") if lr.get("cost") is not None else "—"
        lines.append(f"Последняя задача: {c} · {fmt_k(lr['in'])} → {fmt_k(lr['out'])} токенов · "
                     f"{lr['sec']} с · {lr['turns']} ходов")
    if stt:
        lines.append(f"Через бота всего: ${stt.get('cost', 0):.4f} · {stt.get('runs', 0)} задач · "
                     f"{fmt_k(stt.get('in', 0))} → {fmt_k(stt.get('out', 0))} токенов")
    return "\n".join(lines)


def handle_command(chat, text):
    """Возвращает промпт для Claude или None, если команда обработана ботом."""
    head, _, arg = text.partition(" ")
    name = head[1:].split("@")[0].lower()
    arg = arg.strip()
    key = name.replace("-", "_")
    if key in ("start", "menu"):
        t, m = menu_main()
        tg("sendMessage", chat_id=chat, text=t, parse_mode="HTML", reply_markup=m)
    elif key in ("gen", "generate"):
        t, m = menu_gen()
        tg("sendMessage", chat_id=chat, text=t, parse_mode="HTML", reply_markup=m)
    elif key == "edit":
        tg("sendMessage", chat_id=chat, text="Пришли фото с подписью: /edit что изменить")
    elif key in ("image", "img", "photo", "video", "vid"):
        kind = "video" if key in ("video", "vid") else "image"
        if not arg:
            tg("sendMessage", chat_id=chat, text=f"Напиши: /{key} что сгенерировать. Модель — /gen")
        else:
            threading.Thread(target=run_gen, args=(chat, kind, arg), daemon=True).start()
    elif key == "help":
        tg("sendMessage", chat_id=chat, text=HELP, parse_mode="HTML")
    elif key in ("balance", "bal", "баланс"):
        tg("sendMessage", chat_id=chat, text=balances_text(), parse_mode="HTML")
    elif key == "fast":
        if arg.startswith("model"):
            cfg["fast_model"] = arg[5:].strip(); save_cfg()
        elif arg in ("on", "off", "вкл", "выкл"):
            cfg["speed"] = "auto" if arg in ("on", "вкл") else "full"; save_cfg()
        elif not arg:
            cfg["speed"] = "full" if cfg.get("speed", "auto") == "auto" else "auto"; save_cfg()
        tg("sendMessage", chat_id=chat, text=("⚡ Быстрые ответы ВКЛ: обычные сообщения — сразу, сложные задачи "
                                              "сами уходят в Claude Code. Модель: " + (cfg.get("fast_model") or cfg["model"])
                                              + ". /fast model ИМЯ — сменить, /fast off — всё через Claude Code")
           if cfg.get("speed", "auto") == "auto" else "🐢 Быстрые ответы ВЫКЛ: всё идёт в Claude Code. /fast on — включить")
    elif key == "new":
        switch_session(chat, None)
        tg("sendMessage", chat_id=chat, text="🆕 Новая сессия (прошлая сохранена — /resume)")
    elif key in ("temp", "tmp", "incognito"):
        switch_session(chat, None, temp=True)
        tg("sendMessage", chat_id=chat, text="🕶 Временная сессия: всё, что будет дальше, удалится при переключении. /new — обычная")
    elif key in ("sessions", "sess"):
        t, m = menu_sessions(chat)
        tg("sendMessage", chat_id=chat, text=t, parse_mode="HTML", reply_markup=m)
    elif key in ("to", "say", "agent"):
        if not arg:
            tg("sendMessage", chat_id=chat, text="Напиши: /to уточнение — оно уйдёт работающему агенту прямо во время работы.")
        else:
            t = inject(chat, arg)
            tg("sendMessage", chat_id=chat, text=f"📨 Передал агенту («{t}»)." if t else "Сейчас агент не работает — просто напиши задачу.")
    elif key == "task":
        return arg or None
    elif key == "clear":
        clear_chat(chat)
        tg("sendMessage", chat_id=chat, text="🧹 Чат очищен, сессия удалена.")
    elif key == "chats":
        t, m = menu_chats()
        tg("sendMessage", chat_id=chat, text=t, reply_markup=m)
    elif key == "prompt":
        if arg in ("off", "сброс", "-"):
            chat_prompt(chat, ""); tg("sendMessage", chat_id=chat, text="Инструкции чата сброшены.")
        elif arg:
            chat_prompt(chat, arg); tg("sendMessage", chat_id=chat, text="✅ Запомнил, как вести себя в этом чате.")
        else:
            tg("sendMessage", chat_id=chat, text="Инструкции чата: " + (chat_prompt(chat) or "—") +
               "\nЗадать: /prompt текст · сбросить: /prompt off")
    elif key == "resume":
        t, m = menu_sessions(chat)
        tg("sendMessage", chat_id=chat, text=t, parse_mode="HTML", reply_markup=m)
    elif key == "effort":
        if arg in EFFORTS or arg in ("auto", "авто", "off"):
            cfg["effort"] = arg if arg in EFFORTS else ""; save_cfg()
            tg("sendMessage", chat_id=chat, text="⚡ Effort: " + (cfg["effort"] or "авто"))
        else:
            t, m = menu_effort()
            tg("sendMessage", chat_id=chat, text=t, reply_markup=m)
    elif key == "model":
        if arg:
            cfg["model"] = arg; save_cfg()
            tg("sendMessage", chat_id=chat, text="🧠 Модель: " + arg)
        else:
            t, m = menu_models()
            tg("sendMessage", chat_id=chat, text=t, reply_markup=m)
    elif key == "mode":
        t, m = menu_mode()
        tg("sendMessage", chat_id=chat, text=t, reply_markup=m)
    elif key == "plan" and not arg:
        cfg["mode"] = "bypass" if cfg["mode"] == "plan" else "plan"; save_cfg()
        tg("sendMessage", chat_id=chat, text="Режим: " + MODES[cfg["mode"]])
    elif key == "stop":
        active = list(runs.values())
        for r in active:
            r["stopped"] = True
            kill_run(r["proc"])
        tg("sendMessage", chat_id=chat, text="⏹ Остановлено." if active else "Сейчас ничего не выполняется.")
    elif key == "live":
        t, m = menu_live(chat)
        cur = [d for d, r in runs.items() if r["chat"] == chat and not r["stopped"]]
        if cur and not live.get(chat):  # сразу включаем трансляцию самой свежей задачи
            claude = [d for d, r in active_claude(chat)]
            live_on(chat, (claude or cur)[-1])
            runs[(claude or cur)[-1]]["st"]["dirty"] = True
            t, m = menu_live(chat)
        tg("sendMessage", chat_id=chat, text=t, parse_mode="HTML", **({"reply_markup": m} if m else {}))
    elif key == "status":
        tg("sendMessage", chat_id=chat, text=status_text(chat), parse_mode="HTML")
    elif key == "where":
        if arg in ("github", "gh", "here", "local", "здесь"):
            cfg["where"] = "github" if arg in ("github", "gh") else "local"; save_cfg()
        elif not GH_TOKEN:
            cfg["where"] = "local"
        tg("sendMessage", chat_id=chat, text=("☁️ Claude работает на GitHub Actions (4 ядра, 16 ГБ). /where here — здесь"
                                              if remote_on() else "🏠 Claude работает здесь, на Wispbyte. "
                                              + ("/where github — на GitHub" if GH_TOKEN else "Для GitHub нужен GH_TOKEN в .env")))
    elif key == "files":
        paths = sorted(fs.idx.get("files", {}).keys()) or \
            sorted(os.path.relpath(os.path.join(d, f), WS) for d, _, fs_ in os.walk(WS) for f in fs_)
        dels = sorted(fs.idx.get("deleted", {}))
        send_long(chat, "📁 Файлы проекта:\n" + ("\n".join(paths) or "пусто")
                  + ("\n\n🗑 Удалены:\n" + "\n".join(dels) if dels else ""))
    elif key == "ecc":
        if not ecc_cmds:
            tg("sendMessage", chat_id=chat, text="ECC ещё ставится или не установился. /menu → 🧩 ECC → Обновить.")
        else:
            lines = [f"/{n.replace('-', '_')} — {html.escape(d[:90])}" for n, d in sorted(ecc_cmds.items())]
            send_long(chat, "🧩 Команды Everything Claude Code:\n\n" + "\n".join(lines))
    elif key in ("usage", "cost"):
        tg("sendMessage", chat_id=chat, text=usage_text(), parse_mode="HTML")
    elif key == "agents":
        if not last_agents:
            tg("sendMessage", chat_id=chat, text="В последней задаче агентов не было.")
        else:
            tgctl.rich_send(chat, agents_md(), WS)
    elif key == "skills":
        d = os.path.join(CLAUDE_DIR, "skills")
        names = sorted(os.listdir(d)) if os.path.isdir(d) else []
        own = [n for n in names if not _ours(os.path.join(d, n))]
        txt = (f"🧠 Навыков: {len(names)} (ECC: {len(names) - len(own)}, свои: {len(own)})\n"
               + ("Свои: " + ", ".join(own) if own else "Своих пока нет — попроси: «создай навык для …»"))
        send_long(chat, txt)
    elif key == "repair":
        with fs_lock:
            try:
                gone = fs.check_deleted(batch=0)
                fs.idx["dir_text"] = {}
                fs.rebuild_nav()
                note = "🛠 Оглавление и index.json в канале восстановлены." + \
                    (f"\n🗑 Найдено удалённых: {len(gone)}" if gone else "")
            except Exception as e:
                note = f"Не получилось: {e}"
        tg("sendMessage", chat_id=chat, text=note)
    elif key in PASS:
        return (PASS[key] + " " + arg).strip()
    else:
        # команда ECC или любая другая слэш-команда Claude Code: /code_review → /code-review
        real = next((n for n in list(user_cmds) + list(ecc_cmds) if n.replace("-", "_") == key), name)
        return ("/" + real + " " + arg).strip()
    return None


def media_of(msg):
    if msg.get("photo"):
        p = msg["photo"][-1]
        return p["file_id"], f"photo_{msg['message_id']}.jpg", p.get("file_size", 0)
    for k in ("document", "video", "audio", "voice", "animation", "video_note"):
        d = msg.get(k)
        if d:
            ext = mimetypes.guess_extension(d.get("mime_type") or "") or ""
            name = d.get("file_name") or f"{k}_{msg['message_id']}{ext}"
            return d["file_id"], name, d.get("file_size", 0)
    return None


def download(file_id, name):
    r = tg("getFile", file_id=file_id)
    if not r.get("ok"):
        raise RuntimeError(r.get("description", "getFile"))
    name = re.sub(r"[^\w.\-]+", "_", os.path.basename(name)) or "file"
    os.makedirs(os.path.join(WS, "uploads"), exist_ok=True)
    rel = os.path.join("uploads", name)
    if os.path.exists(os.path.join(WS, rel)):
        base, ext = os.path.splitext(name)
        rel = os.path.join("uploads", f"{base}_{int(time.time())}{ext}")
    with requests.get(f"https://api.telegram.org/file/bot{TOKEN}/{r['result']['file_path']}",
                      stream=True, timeout=120) as resp:
        resp.raise_for_status()
        with open(os.path.join(WS, rel), "wb") as f:
            shutil.copyfileobj(resp.raw, f)
    return rel


def flush_media(key):
    item = media_buf.pop(key, None)
    if not item:
        return
    chat, saved, errors = item["chat"], [], []
    for fid, name, size in item["files"]:
        if size and size > 20 * 2**20:
            errors.append(f"{name}: больше 20 МБ — Telegram не отдаёт ботам такие файлы")
            continue
        try:
            saved.append(download(fid, name))
        except Exception as e:
            errors.append(f"{name}: {e}")
    if errors:
        tg("sendMessage", chat_id=chat, text="⚠️ " + "\n".join(errors))
    if not saved:
        return
    caption = item["caption"]
    imgs = [os.path.join(WS, s) for s in saved if s.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))]
    cmd = caption.split(maxsplit=1)[0].split("@")[0].lower() if caption.startswith("/") else ""
    gkind = {"/video": "video", "/vid": "video", "/image": "image", "/img": "image", "/edit": "image",
             "/photo": "image"}.get(cmd) or (gen_cfg()["mode"] if gen_cfg()["mode"] != "chat" and chat == OWNER else None)
    if imgs and gkind:  # фото + /video → оживить; фото + /edit или /image → отредактировать
        text = caption.split(maxsplit=1)[1] if cmd and len(caption.split(maxsplit=1)) > 1 else ("" if cmd else caption)
        text = text or ("оживи фото, плавное естественное движение" if gkind == "video" else "улучши фото")
        return threading.Thread(target=run_gen, args=(chat, gkind, text, None, imgs), daemon=True).start()
    if caption.startswith("/"):
        caption = handle_command(chat, caption) or ""
    prompt = (caption or "Посмотри приложенные файлы и скажи, что в них.") + \
        "\n\nПриложены файлы (в папке проекта):\n" + "\n".join("- " + s for s in saved) + \
        "\nОткрой их инструментом Read — он умеет показывать изображения и PDF."
    start_task(chat, prompt)


def collect_media(msg, media):
    key = msg.get("media_group_id") or f"m{msg['message_id']}"
    item = media_buf.setdefault(key, {"chat": msg["chat"]["id"], "caption": "", "files": [], "timer": None})
    item["files"].append(media)
    if msg.get("caption") and not item["caption"]:
        item["caption"] = msg["caption"].strip()
    if item["timer"]:
        item["timer"].cancel()
    item["timer"] = threading.Timer(1.5, flush_media, args=(key,))  # альбом приходит пачкой сообщений
    item["timer"].start()


def who_of(msg):
    f = msg.get("from") or {}
    name = (f.get("first_name", "") + " " + f.get("last_name", "")).strip() or msg.get("author_signature") \
        or (msg.get("sender_chat") or {}).get("title") or "?"
    return name + (f" @{f['username']}" if f.get("username") else "") + (" (владелец)" if f.get("id") == OWNER else "")


def addressed(msg, text):
    """Обращение к боту в группе/канале: команда, @упоминание или ответ на сообщение бота."""
    if text.startswith("/"):
        head = text.split()[0]
        return "@" not in head or head.lower().endswith("@" + BOT_USERNAME.lower())
    if BOT_USERNAME and "@" + BOT_USERNAME.lower() in text.lower():
        return True
    return (msg.get("reply_to_message") or {}).get("from", {}).get("id") == BOT_ID


def on_message(msg, channel=False):
    global OWNER
    chat_o = msg["chat"]
    chat, ctype = chat_o["id"], chat_o["type"]
    text = (msg.get("text") or msg.get("caption") or "").strip()
    if not OWNER and ctype == "private" and text == "/start":
        OWNER = cfg["owner"] = msg["from"]["id"]
        save_cfg()
        tg("sendMessage", chat_id=OWNER, text="👋 Ты владелец. Теперь добавь меня админом в приватный канал для файлов.")
    from_owner = (msg.get("from") or {}).get("id") == OWNER
    if ctype == "private" and not from_owner:
        return
    ch = C(chat)
    ch["type"], ch["title"] = ctype, chat_o.get("title") or chat_o.get("first_name", "")
    tgctl.log_msg(chat, msg["message_id"], who_of(msg), text or "[медиа]")

    if ctype == "private":
        if not from_owner:
            return
        guest = False
    else:
        if not (addressed(msg, text) or ch["reply"] == "all"):
            return
        if not from_owner and not channel and ch["access"] != "all":
            return
        guest = not from_owner and not ch["trust"]
        if BOT_USERNAME:
            text = re.sub("@" + re.escape(BOT_USERNAME), "", text, flags=re.I).strip()

    if from_owner:
        live_off(chat)  # написал боту — трансляция прячется; вернуть: /live
    if from_owner and msg.get("text") and OWNER in waiting:
        w = waiting.pop(OWNER)
        if msg["text"].startswith("/"):
            w = None  # команда отменяет ожидание ввода
        if w == "add_provider":
            return add_provider(msg)
        if isinstance(w, tuple) and w[0] == "rename_sess":
            for h in C(chat)["history"]:
                if h["id"] == w[1]:
                    h["title"] = msg["text"][:60]
            save_cfg()
            t, m = menu_sessions(chat)
            return tg("sendMessage", chat_id=chat, text="✅ Переименовал.\n" + t, parse_mode="HTML", reply_markup=m)
        if isinstance(w, tuple):
            return prov_input(msg, *w)
    media = media_of(msg)
    if media and not guest:
        return collect_media(msg, media)
    if not text:
        return
    if text.startswith("/task") and not guest:  # отдельная задача агенту, даже когда он уже работает
        arg = text.partition(" ")[2].strip()
        return start_task(chat, arg, who=who_of(msg), mid=msg["message_id"], force_claude=True) if arg else \
            tg("sendMessage", chat_id=chat, text="Напиши: /task текст — новая отдельная задача агенту.")
    if text.startswith("/"):
        if guest and not text.startswith(("/help", "/start")):
            return
        text = handle_command(chat, text)
        if not text:
            return
    start_task(chat, text, guest=guest, who=who_of(msg), mid=msg["message_id"])


# ---------------- Everything Claude Code (affaan-m/ECC) ----------------
ECC_DIR = os.path.join(HERE, "ecc")


def install_ecc(force=False):
    mark = os.path.join(ECC_DIR, ".ok")
    try:
        if force or not os.path.exists(mark):
            print("installing ECC…", flush=True)
            tmp = ECC_DIR + ".tmp"
            shutil.rmtree(tmp, ignore_errors=True)
            with requests.get(ECC_URL, stream=True, timeout=300) as r:
                r.raise_for_status()
                r.raw.decode_content = True
                with tarfile.open(fileobj=r.raw, mode="r|gz") as tf:  # потоком, без распаковки всего репо
                    for m in tf:
                        rel = m.name.split("/", 1)[1] if "/" in m.name else ""
                        if not m.isfile() or not rel.startswith(ECC_PARTS) or ".." in rel.split("/"):
                            continue
                        dst = os.path.join(tmp, rel)
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        with open(dst, "wb") as f:
                            shutil.copyfileobj(tf.extractfile(m), f)
            shutil.rmtree(ECC_DIR, ignore_errors=True)
            os.rename(tmp, ECC_DIR)
            open(mark, "w").close()
        link_ecc()
    except Exception as e:
        print("ECC install error:", e, flush=True)
    load_ecc_cmds()


def _ours(p):
    return os.path.islink(p) and os.readlink(p).startswith(ECC_DIR)


def link_ecc():
    """Ставит ECC в ~/.claude ссылками: команды, агенты, правила; навыки — по переключателю."""
    if not os.path.isdir(ECC_DIR):
        return
    for kind in ("commands", "agents", "skills"):
        dst_dir = os.path.join(CLAUDE_DIR, kind)
        os.makedirs(dst_dir, exist_ok=True)
        for n in os.listdir(dst_dir):
            if _ours(os.path.join(dst_dir, n)):
                os.unlink(os.path.join(dst_dir, n))
        src_dir = os.path.join(ECC_DIR, kind)
        if not os.path.isdir(src_dir) or (kind == "skills" and not cfg.get("ecc_skills")):
            continue
        for n in os.listdir(src_dir):
            dst = os.path.join(dst_dir, n)
            if not os.path.exists(dst):
                os.symlink(os.path.join(src_dir, n), dst)
    rules = os.path.join(CLAUDE_DIR, "rules")
    os.makedirs(rules, exist_ok=True)
    link = os.path.join(rules, "ecc-common")
    if not os.path.lexists(link) and os.path.isdir(os.path.join(ECC_DIR, "rules", "common")):
        os.symlink(os.path.join(ECC_DIR, "rules", "common"), link)


def load_ecc_cmds():
    ecc_cmds.clear()
    d = os.path.join(ECC_DIR, "commands")
    if not os.path.isdir(d):
        return
    for f in sorted(os.listdir(d)):
        if not f.endswith(".md"):
            continue
        desc = ""
        try:
            for line in open(os.path.join(d, f), encoding="utf-8", errors="ignore").read(3000).splitlines():
                if line.startswith("description:"):
                    desc = line.split(":", 1)[1].strip().strip('"\'')
                    break
        except OSError:
            pass
        ecc_cmds[f[:-3]] = desc or f[:-3]


user_cmds = {}  # свои команды из ~/.claude/commands (не ECC)


def load_user_cmds():
    found = {}
    d = os.path.join(CLAUDE_DIR, "commands")
    if os.path.isdir(d):
        for f in sorted(os.listdir(d)):
            p = os.path.join(d, f)
            if not f.endswith(".md") or _ours(p):
                continue
            desc = ""
            try:
                for line in open(p, encoding="utf-8", errors="ignore").read(3000).splitlines():
                    if line.startswith("description:"):
                        desc = line.split(":", 1)[1].strip().strip('"\'')
                        break
            except OSError:
                pass
            found[f[:-3]] = desc or f[:-3]
    return found


def user_cmds_changed():
    new = load_user_cmds()
    if new != user_cmds:
        user_cmds.clear(); user_cmds.update(new)
        return True
    return False


def register_commands(limit=100):
    cmds = [{"command": c, "description": d} for c, d in BUILTIN]
    seen = {c for c, _ in BUILTIN}
    for n, d in sorted(user_cmds.items()):
        c = n.replace("-", "_").lower()
        if c not in seen and re.fullmatch(r"[a-z0-9_]{1,32}", c):
            seen.add(c)
            cmds.append({"command": c, "description": ("⭐ " + d)[:60]})
    for n, d in sorted(ecc_cmds.items()):
        c = n.replace("-", "_").lower()
        if len(cmds) >= limit or c in seen or not re.fullmatch(r"[a-z0-9_]{1,32}", c):
            continue
        seen.add(c)
        cmds.append({"command": c, "description": ("ECC: " + d)[:60]})
    r = tg("setMyCommands", commands=cmds)
    if not r.get("ok"):
        print("setMyCommands:", limit, r.get("description"), flush=True)
        if "TOO_MUCH" in (r.get("description") or "") and limit > len(BUILTIN):
            return register_commands(max(len(BUILTIN), limit - 20))  # остальные команды ECC — в /ecc


def on_my_chat_member(u):
    global CHANNEL
    chat, new = u["chat"], u["new_chat_member"]
    if chat["type"] != "private" and str(chat["id"]) != str(CHANNEL):
        if new["status"] in ("left", "kicked"):
            cfg.get("chats", {}).pop(str(chat["id"]), None); save_cfg()
        elif CHANNEL or chat["type"] != "channel":
            ch = C(chat["id"]); ch["type"], ch["title"] = chat["type"], chat.get("title", "")
            save_cfg()
            if u["from"]["id"] == OWNER:
                tg("sendMessage", chat_id=OWNER, text=f"👥 Меня добавили в «{chat.get('title', '')}». "
                   "Отвечаю там на @упоминания и ответы. Настройки: /chats")
            return
    if chat["type"] == "channel" and not CHANNEL and new["status"] == "administrator" \
            and u["from"]["id"] == OWNER:
        CHANNEL = cfg["channel"] = str(chat["id"])
        fs.cid = chat["id"]
        save_cfg()
        with fs_lock:
            fs.load(); fs.rebuild_nav()
        tg("sendMessage", chat_id=OWNER, text=f"📁 Канал «{chat.get('title', '')}» подключён. Пиши задачу!")


def ensure_claude():
    global CLAUDE
    os.chmod(os.path.join(HERE, "rexec"), 0o755)
    local = os.path.expanduser("~/.local/bin/claude")
    if subprocess.run(["sh", "-c", f"command -v {CLAUDE}"], capture_output=True).returncode == 0:
        return
    if not os.path.exists(local):
        print("installing Claude Code…", flush=True)
        subprocess.run(["sh", "-c", "curl -fsSL https://claude.ai/install.sh | bash"])
    if os.path.exists(local):
        CLAUDE = local


def fs_watch():
    """В Bot API нет события «сообщение удалено», поэтому по кругу проверяем, живы ли
    сообщения с файлами (порциями, чтобы не упереться в лимиты Telegram)."""
    while True:
        time.sleep(60)
        if not CHANNEL:
            continue
        try:
            with fs_lock:
                gone = fs.check_deleted(batch=15)
            if gone and OWNER:
                tg("sendMessage", chat_id=OWNER, disable_notification=True, parse_mode="HTML",
                   link_preview_options={"is_disabled": True},
                   text="🗑 Удалено из канала — убрал из проекта (ссылка сохранена):\n" + "\n".join(
                       f'<a href="{fs.link(fs.idx["deleted"][p]["mid"])}">{html.escape(p)}</a>' for p in gone))
        except Exception as e:
            print("fs_watch:", e, flush=True)


def keep_render_awake():
    """Render free засыпает через 15 мин без запросов и теряет /tmp — вместе с сайтами.
    Один лёгкий GET раз в 10 минут держит его бодрым (это ~1 запрос, не нагрузка)."""
    url = os.environ.get("REXEC_URL", "").rstrip("/")
    while url:
        try:
            requests.get(url + "/", timeout=30)
        except Exception:
            pass
        time.sleep(600)


BOT_ID, BOT_USERNAME = 0, ""


def main():
    global BOT_ID, BOT_USERNAME
    me = tg("getMe").get("result") or {}
    BOT_ID, BOT_USERNAME = me.get("id", 0), me.get("username", "")
    if OWNER and ("session" in cfg or "history" in cfg):  # перенос старых сессий в личный чат
        ch = C(OWNER); ch["type"] = "private"
        ch["session"] = ch["session"] or cfg.get("session")
        ch["history"] = ch["history"] or cfg.get("history") or []
    cfg.pop("session", None); cfg.pop("history", None)
    os.chmod(os.path.join(HERE, "tgctl"), 0o755)
    save_cfg()
    ensure_claude()
    if CHANNEL:
        fs.load()
        fs.restore()
    load_ecc_cmds()
    user_cmds_changed()
    register_commands()
    threading.Thread(target=lambda: (install_ecc(), register_commands()), daemon=True).start()
    threading.Thread(target=keep_render_awake, daemon=True).start()
    threading.Thread(target=fs_watch, daemon=True).start()
    threading.Thread(target=lambda: (env_providers(), refresh_models()), daemon=True).start()
    try:  # задачи на GitHub, которые шли до перезапуска бота, — подключаемся обратно
        jobs = json.load(open(JOBS_PATH)) if os.path.exists(JOBS_PATH) else {}
    except Exception:
        jobs = {}
    REMOTE_JOBS.update(jobs)
    if jobs and os.environ.get("REXEC_URL"):
        for info in jobs.values():
            threading.Thread(target=run_claude, args=(info["chat"], info["prompt"], info.get("guest", False),
                                                      info.get("who", "владелец"), info.get("mid"), info),
                             daemon=True).start()
        print(f"reattached {len(jobs)} job(s)", flush=True)
    print("bot started", flush=True)
    offset = 0
    while True:
        upd = tg("getUpdates", offset=offset, timeout=50,
                 allowed_updates=["message", "callback_query", "channel_post", "my_chat_member",
                                  "stopped_message_generation", "poll_answer"])
        if not upd.get("ok"):
            time.sleep(3)
            continue
        for u in upd["result"]:
            offset = u["update_id"] + 1
            try:
                if "stopped_message_generation" in u:  # нажата нативная кнопка Stop
                    r = runs.get(u["stopped_message_generation"].get("draft_id"))
                    if r:
                        r["stopped"] = True
                        kill_run(r["proc"])
                elif "poll_answer" in u:
                    on_poll_answer(u["poll_answer"])
                elif "my_chat_member" in u:
                    on_my_chat_member(u["my_chat_member"])
                elif "callback_query" in u:
                    on_callback(u["callback_query"])
                elif "channel_post" in u and str(u["channel_post"]["chat"]["id"]) == str(CHANNEL):
                    with fs_lock:
                        fs.on_channel_post(u["channel_post"])
                elif "channel_post" in u:
                    on_message(u["channel_post"], channel=True)
                elif "message" in u:
                    on_message(u["message"])
            except Exception as e:
                print("update error:", e, flush=True)


if __name__ == "__main__":
    main()
